import {
  comboboxEvents,
  comboboxParts,
  type ComboboxItem,
  comboboxContract,
} from "@skryensya/core/combobox";
import { formFieldParts } from "@skryensya/core/form-field";
import { combobox } from "@skryensya/core/machines";
import { normalizeProps, Portal, useMachine } from "@zag-js/react";
import { useId, useMemo, useRef, useState, type ReactNode, type RefObject } from "react";
import { useAnchored } from "./anchored.js";
import { Icon } from "./icon.js";
const cx = (...classes: Array<string | undefined>) =>
  classes.filter(Boolean).join(" ");
const combiningMarks = /\p{M}+/gu;
const searchKey = (value: string) =>
  value.normalize("NFD").replace(combiningMarks, "").toLocaleLowerCase();
type HighlightSource = "keyboard" | "pointer" | undefined;
// The keys that move the highlight inside the listbox (the same ones the machine handles).
const navigationKeys = new Set([
  "ArrowDown",
  "ArrowUp",
  "Home",
  "End",
  "PageUp",
  "PageDown",
]);
// The machine takes an array even when only one thing can be chosen. Authored markup carries a
// single `data-value`, so a lone string has to reach it as the one-element array it means.
const asValues = (value: string | readonly string[] | undefined) =>
  value === undefined ? undefined : typeof value === "string" ? [value] : [...value];
const defaultRemoveLabel = (item: ComboboxItem) => `Quitar ${item.label}`;
const defaultResultCountLabel = ({ count }: { count: number }) =>
  count === 1 ? "1 resultado disponible" : `${count} resultados disponibles`;

export type ComboboxProps = {
  /**
   * Where the positioned listbox is portalled. Absent it goes to the body, which is right in a page
   * and wrong in the gate: the listbox would land outside the box G2 measures, and the two bindings
   * would be compared with one of them missing its whole floating half.
   */
  container?: RefObject<HTMLElement>;
  id?: string;
  name?: string;
  /** Field name. Contract slot `label` accepts text; keep this a string for emit parity. */
  label: string;
  hint?: string;
  error?: string;
  items: readonly ComboboxItem[];
  placeholder?: string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  multiple?: boolean;
  value?: string | readonly string[];
  defaultValue?: string | readonly string[];
  inputValue?: string;
  defaultInputValue?: string;
  openOnClick?: boolean;
  allowCustomValue?: boolean;
  triggerIndicator?: ReactNode;
  itemIndicator?: ReactNode;
  clearIndicator?: ReactNode;
  removeIndicator?: ReactNode;
  clearLabel?: string;
  selectedLabel?: string;
  removeLabel?: (item: ComboboxItem) => string;
  emptyLabel?: string;
  resultCountLabel?: (details: { count: number; inputValue: string }) => string;
  onValueChange?: (details: { value: string[] }) => void;
  onInputValueChange?: (details: { inputValue: string }) => void;
  /** How the field is drawn: `plain`, `brutalist` or `frosted`. Absent means plain. */
  appearance?: (typeof comboboxContract.options.appearance.values)[number];
};

export function Combobox({
  allowCustomValue,
  appearance,
  clearLabel = "Limpiar selección",
  clearIndicator,
  container,
  defaultInputValue = "",
  defaultValue,
  disabled,
  emptyLabel = "Sin resultados",
  error,
  hint,
  id,
  inputValue,
  itemIndicator,
  items,
  label,
  multiple,
  name,
  onInputValueChange,
  onValueChange,
  openOnClick = true,
  placeholder,
  readOnly,
  removeIndicator,
  removeLabel = defaultRemoveLabel,
  required,
  resultCountLabel = defaultResultCountLabel,
  selectedLabel = "Valores seleccionados",
  triggerIndicator,
  value,
}: ComboboxProps) {
  const generatedId = useId();
  const machineId = id ?? generatedId;
  const rootRef = useRef<HTMLDivElement>(null);
  const hintId = `${machineId}-hint`;
  const errorId = `${machineId}-error`;
  const [query, setQuery] = useState(defaultInputValue);
  /*
   * ── Virtual focus ────────────────────────────────────────────────────────────────────────────
   *
   * DOM focus never leaves the input: `aria-activedescendant` points at the highlighted option, so
   * nothing on screen says where the arrow keys have landed unless the option says it. It carries a
   * real focus ring, and while it does, the control drops its own; one ring at a time, so the ring
   * *moves* into the list and back out instead of stacking a box inside a box.
   *
   * Both attributes are gated on which device moved the highlight last, because the machine also
   * highlights on `pointermove` and a focus ring chasing the cursor reads as broken focus. Under the
   * pointer the hover tint carries the highlight alone. The updater returns the previous value when
   * nothing changed, so a mouse crossing the list does not re-render on every frame.
   */
  // Starts at `pointer`, matching the enhancer: at rest no key has moved the highlight, and only
  // `keyboard` changes what is drawn. Leaving it unset meant the two bindings disagreed about the
  // attribute before anyone had touched the control.
  const [highlightSource, setHighlightSource] = useState<HighlightSource>("pointer");
  const keepHighlightSource =
    (next: HighlightSource) => (previous: HighlightSource) =>
      previous === next ? previous : next;
  const effectiveQuery = inputValue ?? query;
  // Folded once per item list, not once per row per keystroke: `searchKey` normalizes to NFD and
  // strips combining marks, which is the most expensive thing in the filter and never changes.
  const searchKeys = useMemo(() => items.map(({ label }) => searchKey(label)), [items]);
  const allItems = useMemo(() => [...items], [items]);
  const filteredItems = useMemo(() => {
    const needle = searchKey(effectiveQuery.trim());
    if (!needle) return allItems;
    return items.filter((_, index) => searchKeys[index].includes(needle));
  }, [allItems, effectiveQuery, items, searchKeys]);
  const collection = useMemo(
    () =>
      combobox.collection<ComboboxItem>({
        items: filteredItems,
        itemToString: (item) => item.label,
        itemToValue: (item) => item.value,
        isItemDisabled: (item) => Boolean(item.disabled),
      }),
    [filteredItems],
  );
  const service = useMachine(combobox.machine, {
    id: machineId,
    collection,
    name,
    disabled,
    invalid: Boolean(error),
    readOnly,
    required,
    multiple,
    value: asValues(value),
    defaultValue: asValues(defaultValue),
    inputValue,
    defaultInputValue,
    openOnClick,
    allowCustomValue,
    placeholder,
    // A search that was never resolved into a selection is still the user's work: leaving the field
    // (blur, click outside, Escape) must not throw it away and leave them retyping. `preserve` is
    // the only selectionBehavior that keeps it, because the machine reverts the input on every one
    // of those exits. The cost is that CHOOSING no longer writes the label either, so `onValueChange`
    // below does that write itself: preserve on leave, replace on select (mirrors the vanilla layer).
    selectionBehavior: "preserve",
    translations: {
      clearTriggerLabel: clearLabel,
    },
    onInputValueChange(details) {
      // Only what the user TYPED is a filter. The machine writes this input too (the label after a
      // select, "" after clear), and filtering on that would leave the list showing the single row
      // you just picked the next time it opens. Any non-typed write resets to the full set.
      setQuery(details.reason === "input-change" ? details.inputValue : "");
      const next = { inputValue: details.inputValue };
      onInputValueChange?.(next);
      rootRef.current?.dispatchEvent(
        new CustomEvent(comboboxEvents.inputValueChange, { bubbles: true, detail: next }),
      );
    },
    onValueChange(details) {
      const next = { value: details.value };
      onValueChange?.(next);
      rootRef.current?.dispatchEvent(
        new CustomEvent(comboboxEvents.valueChange, { bubbles: true, detail: next }),
      );
      // The other half of `selectionBehavior: "preserve"`. Single: the input shows what was chosen.
      // Multiple: the chip already shows it, so the query is spent; clear it so the next search
      // starts from the whole list instead of the one match that produced this chip.
      queueMicrotask(() => {
        const label = multiple ? "" : (details.items.at(-1)?.label ?? "");
        if (api.inputValue !== label) api.setInputValue(label, "script");
      });
    },
  });
  const api = combobox.connect(service, normalizeProps);

  /* The anchor is the whole CONTROL, not the chevron button: the listbox lines up with the field the
   * user is typing into, and anchoring it to the chevron would pin it to a 32px square. */
  const anchor = useAnchored(machineId);
  const inputProps = api.getInputProps();
  const describedBy =
    [
      inputProps["aria-describedby"],
      hint ? hintId : undefined,
      error ? errorId : undefined,
    ]
      .filter(Boolean)
      .join(" ") || undefined;
  // Show the clear ✕ whenever there is something to clear (a chosen value OR text still in the
  // input), and hide it when the field is truly empty (mirrors the vanilla layer).
  const showClear = api.hasSelectedItems || api.inputValue.length > 0;

  return (
    <div
      {...api.getRootProps()}
      className={cx(formFieldParts.root, comboboxParts.root)}
      data-appearance={appearance}
      data-disabled={disabled ? "" : undefined}
      data-sk-combobox=""
      data-virtual-focus={
        highlightSource === "keyboard" && api.open && api.highlightedValue
          ? ""
          : undefined
      }
      onKeyDownCapture={(event) => {
        if (!navigationKeys.has(event.key)) return;
        setHighlightSource(keepHighlightSource("keyboard"));
      }}
      ref={rootRef}
    >
      <label
        {...api.getLabelProps()}
        className={cx(formFieldParts.label, comboboxParts.label)}
      >
        {label}
        {required ? (
          <span aria-hidden="true" className={formFieldParts.requiredIndicator}>
            *
          </span>
        ) : null}
      </label>
      {hint ? (
        <div className={formFieldParts.hint} id={hintId}>
          {hint}
        </div>
      ) : null}
      <div
        {...api.getControlProps()}
        {...anchor.anchor(comboboxParts.control)}
        data-readonly={readOnly ? "" : undefined}
      >
        <div className={comboboxParts.value}>
          {multiple && api.selectedItems.length ? (
            <div
              aria-label={selectedLabel}
              className={comboboxParts.selectedItems}
              role="list"
            >
              {api.selectedItems.map((item) => (
                <span
                  className={comboboxParts.selectedItem}
                  key={item.value}
                  role="listitem"
                >
                  <span className={comboboxParts.selectedItemLabel}>
                    {item.label}
                  </span>
                  <button
                    aria-label={removeLabel(item)}
                    className={cx(
                      comboboxParts.removeTrigger,
                      "sk-button",
                      "sk-interactive",
                    )}
                    data-icon-only=""
                    data-size="sm"
                    data-variant="ghost"
                    onClick={() => {
                      api.clearValue(item.value);
                      api.focus();
                    }}
                    type="button"
                  >
                    {removeIndicator ?? <Icon name="close" size="sm" />}
                  </button>
                </span>
              ))}
            </div>
          ) : null}
          <input
            {...inputProps}
            aria-describedby={describedBy}
            aria-errormessage={error ? errorId : undefined}
            className={comboboxParts.input}
          />
        </div>
        {/* Rendered-and-hidden rather than conditional, which is what the enhancer can do with
            authored markup and therefore what the contract's template says. `hidden` keeps it out
            of the accessibility tree exactly as absence would, and it is what the CSS styles. */}
        <button
          {...api.getClearTriggerProps()}
          className={cx(comboboxParts.clear, "sk-button", "sk-interactive")}
          data-icon-only=""
          data-size="sm"
          data-variant="ghost"
          hidden={!showClear}
          tabIndex={0}
          type="button"
        >
          {clearIndicator ?? <Icon name="close" size="sm" />}
        </button>
        {/*
          Decorative, not a second control: Zag's own `getTriggerProps()` already defaults this to
          `tabIndex: -1` (never a Tab stop), and every open path here - typing, `openOnClick` on
          the input itself - never went through it either. What made it read as an independent
          button was purely visual (its own `.sk-button` ghost hover/pressed feedback on a mouse
          click Zag still wired up), not a real second interaction surface. `aria-hidden` and a
          plain `span` remove that affordance instead of just restyling it; the input's own
          `role="combobox"` + `aria-expanded` already say everything a screen reader needs.
        */}
        <span aria-hidden="true" className={comboboxParts.trigger} data-state={api.open ? "open" : "closed"}>
          {triggerIndicator ?? (
            <>
              <span data-state="closed">
                <Icon name="chevron-down" size="md" />
              </span>
              <span data-state="open">
                <Icon name="chevron-up" size="md" />
              </span>
            </>
          )}
        </span>
      </div>
      {error ? (
        <div className={formFieldParts.error} id={errorId}>
          {error}
        </div>
      ) : null}
      <div
        aria-atomic="true"
        className={cx(comboboxParts.status, "sk-visually-hidden")}
        role="status"
      >
        {api.open
          ? resultCountLabel({
              count: filteredItems.length,
              inputValue: api.inputValue,
            })
          : null}
      </div>
      <Portal container={container}>
        <div {...anchor.positioner(api.getPositionerProps(), comboboxParts.positioner)}>
          <div
            {...api.getContentProps()}
            className={cx(comboboxParts.content, "sk-scrollbar")}
            data-highlight-source={highlightSource}
            onPointerMove={() => setHighlightSource(keepHighlightSource("pointer"))}
          >
            {filteredItems.map((item) => (
              <div
                {...api.getItemProps({ item })}
                /*
                 * Zag's `aria-selected` tracks the COMMITTED value, not the row under
                 * `aria-activedescendant`. The WAI reference implementation
                 * (`combobox-autocomplete.js`, `setCurrentOptionStyle`) does the opposite for
                 * single-select: it moves `aria-selected="true"` onto whichever option is highlighted
                 * as you arrow through the list, before Enter commits anything. That is what
                 * "visually indicated as the currently selected value" means in the APG's
                 * roles/states table. Multiple stays on Zag's default: with chips, `aria-selected`
                 * genuinely means "part of the chosen set" (aria-multiselectable="true"), a state the
                 * base combobox pattern does not cover. Placed after the spread so it wins.
                 */
                aria-selected={
                  multiple
                    ? api.getItemState({ item }).selected
                      ? "true"
                      : undefined
                    : item.value === api.highlightedValue
                      ? "true"
                      : undefined
                }
                className={`${comboboxParts.item} sk-interactive`}
                /* What the enhancer reads to build its collection: a row's `textContent` is label +
                   description + indicator glued together, which is not the label. Written here too
                   so the two bindings land on the same row. */
                data-description={item.description}
                data-value-text={item.label}
                key={item.value}
              >
                <span className={comboboxParts.itemCopy}>
                  <span
                    {...api.getItemTextProps({ item })}
                    className={comboboxParts.itemLabel}
                  >
                    {item.label}
                  </span>
                  {item.description ? (
                    <span className={comboboxParts.itemDescription}>
                      {item.description}
                    </span>
                  ) : null}
                </span>
                <span
                  {...api.getItemIndicatorProps({ item })}
                  className={comboboxParts.itemIndicator}
                >
                  {itemIndicator ?? "✓"}
                </span>
              </div>
            ))}
            {/* Same rendered-and-hidden rule as the clear control above. */}
            <div
              className={comboboxParts.empty}
              hidden={filteredItems.length > 0}
              role="presentation"
            >
              {emptyLabel}
            </div>
          </div>
        </div>
      </Portal>
    </div>
  );
}
