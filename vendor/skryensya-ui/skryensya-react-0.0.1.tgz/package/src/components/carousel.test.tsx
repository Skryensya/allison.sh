import type { UsageTree } from "@skryensya/core/usage-tree";
import { createRef } from "react";
import { render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { Carousel, CarouselSlide, type CarouselHandle } from "./carousel.js";
import { loadTree, renderTree } from "../render-tree.js";

describe("Carousel", () => {
  it("renders a section region with a scroll-snap track of slides", () => {
    const ui = render(
      <Carousel aria-label="Destacados">
        <CarouselSlide>Uno</CarouselSlide>
        <CarouselSlide>Dos</CarouselSlide>
        <CarouselSlide>Tres</CarouselSlide>
      </Carousel>,
    );

    const region = ui.container.querySelector(".sk-carousel")!;
    expect(region.tagName).toBe("SECTION");
    expect(region.getAttribute("data-sk-carousel")).toBe("");
    expect(region.getAttribute("aria-label")).toBe("Destacados");

    const track = region.querySelector(".sk-carousel__track")!;
    // A div, not a list: the machine gives each slide role="group", which takes it out of the list.
    expect(track.tagName).toBe("DIV");
    expect(track.querySelectorAll("div.sk-carousel__slide")).toHaveLength(3);
  });

  it("maps style-backed tree options onto the Carousel host", async () => {
    const tree: UsageTree = {
      contract: "carousel",
      signature: "Carousel",
      options: { mounted: false, slideSize: "min(42%, 14rem)" },
      children: {
        contract: "carousel",
        signature: "CarouselSlide",
        children: "Search",
      },
    };

    await loadTree(tree);
    const ui = render(<>{renderTree(tree)}</>);
    const region = ui.container.querySelector<HTMLElement>(".sk-carousel")!;

    expect(region.hasAttribute("data-sk-carousel")).toBe(false);
    expect(region.hasAttribute("data-slide-size")).toBe(false);
    expect(region.style.getPropertyValue("--sk-carousel-slide-size")).toBe(
      "min(42%, 14rem)",
    );
  });

  it("exposes a snapTo handle that dispatches the goto command the enhancer listens for", () => {
    const ref = createRef<CarouselHandle>();
    const ui = render(
      <Carousel ref={ref}>
        <CarouselSlide>Uno</CarouselSlide>
        <CarouselSlide>Dos</CarouselSlide>
      </Carousel>,
    );

    const root = ui.container.querySelector(".sk-carousel")!;
    const onGoto = vi.fn();
    root.addEventListener("sk:carouselgoto", onGoto as EventListener);

    ref.current?.snapTo(1);

    expect(onGoto).toHaveBeenCalledTimes(1);
    expect((onGoto.mock.calls[0][0] as CustomEvent).detail).toEqual({ index: 1 });
    expect(ref.current?.element).toBe(root);
  });
});
