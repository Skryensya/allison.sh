import { qrGeometry, qrCodeParts, type QrLevel, type QrMask, type QrModuleShape, type QrPolarity, type QrSize, type QrTone, qrCodeContract } from "@skryensya/core/qr-code";
import type { CSSProperties, HTMLAttributes, ReactNode, Ref } from "react";

/* Export works on the rendered element: pass the `ref` of a <QRCode> to these. */
export {
  QrExportError,
  downloadQrCode,
  qrCodeToBlob,
  qrCodeToDataUrl,
  qrCodeToSvg,
  type QrExportOptions,
  type QrExportType,
} from "@skryensya/core/qr-code-export";

/* Derived, never restated: the default lives in the contract. */
const { level: levelOption, mask: maskOption, logoRatio: logoRatioOption, polarity: polarityOption, quietZone: quietZoneOption, moduleShape: moduleShapeOption, qrSize: qrSizeOption, tone: toneOption } = qrCodeContract.options;

type QRCodeStyle = CSSProperties & { "--sk-qr-code-logo-ratio"?: number };

export type QRCodeProps = Omit<HTMLAttributes<HTMLDivElement>, "children"> & {
  /** The string the symbol carries. */
  value: string;
  /** What the code DOES, for assistive technology. Never the raw value: see the contract. */
  label: string;
  level?: QrLevel;
  /** One of the eight mask patterns, or `auto` to let the standard's penalty rules choose. */
  mask?: QrMask;
  shape?: QrModuleShape;
  quietZone?: number;
  logoRatio?: number;
  size?: QrSize;
  tone?: QrTone;
  polarity?: QrPolarity;
  /** Anything the kit publishes, laid over the cleared middle. Pair it with `logoRatio`. */
  logo?: ReactNode;
  /** The rendered root: what `downloadQrCode` and the other export functions take. */
  ref?: Ref<HTMLDivElement>;
};

/*
 * The React half of the QRCode contract.
 *
 * IT CALLS THE SAME `qrGeometry` THE MARKUP EMITTER CALLS, which is the whole arrangement: the
 * encoder lives in Core (decision 13) so that a symbol cannot come out one way in authored markup
 * and another way here. Two implementations of ISO/IEC 18004 that agree by inspection is not a thing
 * anyone can verify in a diff; one function called twice is.
 *
 * There is no memo around it because `qrGeometry` already caches, and a component that re-renders
 * with the same value therefore pays a map lookup rather than an encode.
 */
export function QRCode({
  className,
  label,
  level = levelOption.default,
  mask = maskOption.default,
  logo,
  logoRatio = logoRatioOption.default,
  polarity = polarityOption.default,
  quietZone = quietZoneOption.default,
  shape = moduleShapeOption.default,
  size = qrSizeOption.default,
  style,
  tone = toneOption.default,
  value,
  ...props
}: QRCodeProps) {
  const { path, extent } = qrGeometry(value, {
    level,
    mask,
    moduleShape: shape,
    quietZone,
    logoRatio,
  });

  return (
    <div
      {...props}
      aria-label={label}
      className={className ? `${qrCodeParts.root} ${className}` : qrCodeParts.root}
      data-level={level}
      data-mask={mask}
      data-module-shape={shape}
      data-polarity={polarity}
      data-quiet-zone={quietZone}
      data-size={size}
      data-tone={tone}
      /* What it encodes, stated in the markup like the other three encoder inputs: the Vanilla
         enhancer redraws from these, and the two bindings must emit the same attributes. */
      data-value={value}
      role="img"
      /* The ratio reaches the stylesheet as a custom property, which is what sizes the logo box;
         the markup emitter writes the same one from the contract's `styleProperty`. */
      style={{ ...style, "--sk-qr-code-logo-ratio": logoRatio } as QRCodeStyle}
    >
      <svg
        aria-hidden="true"
        className={qrCodeParts.frame}
        focusable="false"
        viewBox={`0 0 ${extent} ${extent}`}
        xmlns="http://www.w3.org/2000/svg"
      >
        <path className={qrCodeParts.modules} d={path} fill="currentColor" />
      </svg>
      {logo === undefined ? null : <div className={qrCodeParts.logo}>{logo}</div>}
    </div>
  );
}
