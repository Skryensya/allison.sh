import { dialogParts, dialogContract } from "@skryensya/core/dialog";
import { vaulDataParts, vaulScope } from "@skryensya/core/vaul";
import type { SignatureOptionsOf } from "@skryensya/core/contract";
import { useId, type DialogHTMLAttributes, type ReactNode } from "react";
import { Icon } from "./icon.js";
import { useModalTabWrap } from "./modal-tab-wrap.js";

/* Derived, never restated: the default lives in the contract. */
const {
  alert: alertOption,
  appearance: appearanceOption,
  closeLabel: closeLabelOption,
  vaul: vaulOption,
} = dialogContract.options;

/*
 * DIALOG: the centred modal box, and a binding that is markup and one hook.
 *
 * No state and no machine, on purpose: the behaviour is the platform's. The consumer calls
 * `showModal()` and the browser owns the top layer, the backdrop, the inert page and Escape. The
 * one gap it leaves, Tab leaving for the browser's toolbar at either end, is closed by
 * `useModalTabWrap` (decision 24), which holds no state of its own. What the system otherwise
 * contributes is the anatomy, which is what makes this a contract both bindings derive from rather
 * than a component one of them implements, the same reason `Select.native` is one.
 *
 * The close control is a `<form method="dialog">` rather than an onClick: that is the platform's own
 * way to close a dialog, it works before any script runs, and its `value` lets the opener tell a
 * cancel from a confirm.
 */
type DialogOptions = SignatureOptionsOf<typeof dialogContract, "Dialog">;

export type DialogProps = DialogHTMLAttributes<HTMLDialogElement> & {
  /** Matches the contract slot: plain text that names the dialog. */
  title: string;
  children: ReactNode;
  footer?: ReactNode;
  closeLabel?: string;
  /**
   * Opts into Dialog Vaul: the same box slides from `block-end` and gains a drag handle below the
   * desktop breakpoint (`patterns/dialog-vaul.css`). Dragging itself is the Vanilla enhancer's,
   * same asymmetry as `Vaul`'s own `drawer`: this binding renders markup, never the gesture.
   */
  vaul?: boolean;
  /**
   * Renders as an Alert Dialog: `role="alertdialog"`, `aria-modal` authored explicitly, and
   * `aria-describedby` pointing at the body. For a message needing the user's IMMEDIATE
   * attention (a destructive confirmation, a blocking error), not a dialog that merely contains
   * one. Focus is still the platform's: put `autofocus` on the least destructive action yourself.
   */
  alert?: boolean;
  footerAlign?: DialogOptions["footerAlign"];
  /** How the surface is drawn: `plain`, `brutalist` or `frosted`. */
  appearance?: DialogOptions["appearance"];
};

export function Dialog({
  alert = alertOption.default,
  appearance = appearanceOption.default,
  children,
  className,
  closeLabel = closeLabelOption.default,
  footer,
  footerAlign,
  title,
  vaul = vaulOption.default,
  ...props
}: DialogProps) {
  const titleId = useId();
  const bodyId = useId();
  useModalTabWrap();

  return (
    <dialog
      {...props}
      aria-describedby={alert ? bodyId : undefined}
      aria-labelledby={titleId}
      aria-modal={alert ? "true" : undefined}
      className={className ? `${dialogParts.root} ${className}` : dialogParts.root}
      data-appearance={appearance}
      data-footer-align={footerAlign}
      data-sk-dialog-vaul={vaul ? "" : undefined}
      // The enhancer's drag axis is generic and defaults to `inline-start` with nothing to read;
      // `dialog-vaul.css` only ever slides from the bottom, so this is not a choice: see core.
      data-edge={vaul ? "block-end" : undefined}
      /* The vaul enhancer's scope markers, rendered at rest as `Vaul` does. */
      data-part={vaul ? vaulDataParts.root : undefined}
      data-scope={vaul ? vaulScope : undefined}
      role={alert ? "alertdialog" : undefined}
    >
      {vaul ? <div aria-hidden="true" data-part="handle" /> : null}
      <header className={dialogParts.header}>
        <h2 className={dialogParts.title} id={titleId}>
          {title}
        </h2>
        <form method="dialog">
          <button
            aria-label={closeLabel}
            className={`${dialogParts.close} sk-button sk-interactive`}
            data-icon-only=""
            data-size="sm"
            data-variant="ghost"
            type="submit"
            value="cancel"
          >
            <Icon name="close" size="sm" />
          </button>
        </form>
      </header>
      <div className={dialogParts.body} id={alert ? bodyId : undefined}>
        {children}
      </div>
      {/* A form, not a <footer>: `method="dialog"` closes and reports which button did it. */}
      {footer ? (
        <form className={dialogParts.footer} method="dialog">
          {footer}
        </form>
      ) : null}
    </dialog>
  );
}
