import { render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Callout } from "./callout.js";

describe("Callout", () => {
  it("serializes its appearance beside its tone, plain by default", () => {
    const plain = render(<Callout title="Plain">Body</Callout>);
    expect(plain.container.querySelector(".sk-callout")?.getAttribute("data-appearance")).toBe("plain");
    const brutalist = render(<Callout appearance="brutalist" tone="warning" title="Brutalist">Body</Callout>);
    const root = brutalist.container.querySelector(".sk-callout");
    expect(root?.getAttribute("data-appearance")).toBe("brutalist");
    expect(root?.getAttribute("data-tone")).toBe("warning");
  });

  it("announces danger assertively and everything else politely", () => {
    const plain = render(<Callout>Heads up</Callout>);
    expect(plain.getByRole("status").getAttribute("data-tone")).toBe("neutral");
    expect(plain.getByRole("status").getAttribute("aria-live")).toBe("polite");
    plain.unmount();

    const info = render(<Callout tone="info">Heads up</Callout>);
    expect(info.getByRole("status").getAttribute("aria-live")).toBe("polite");
    info.unmount();

    const danger = render(<Callout tone="danger">Broke</Callout>);
    expect(danger.getByRole("alert").getAttribute("aria-live")).toBe("assertive");
    danger.unmount();
  });

  it("marks the live region atomic, same fix already applied to Toast", () => {
    const ui = render(<Callout tone="danger">Broke</Callout>);
    expect(ui.getByRole("alert").getAttribute("aria-atomic")).toBe("true");
  });

  /*
   * Purely informational: no dismiss exists anywhere in the binding to test for, unlike Toast.
   */
  it("renders no dismiss control, ever", () => {
    const ui = render(<Callout title="Saved" tone="success">Done</Callout>);
    expect(ui.container.querySelector(".sk-callout__dismiss")).toBeNull();
    expect(ui.getByRole("status").hasAttribute("data-dismissible")).toBe(false);
  });

  it("renders an icon and optional actions through explicit parts", () => {
    const ui = render(
      <Callout actions={<a href="/billing">Review plan</a>} icon="!" title="Plan expires" tone="warning">
        Renew before Friday.
      </Callout>,
    );

    const callout = ui.getByRole("status");
    expect(callout.querySelector(".sk-callout__icon")).not.toBeNull();
    expect(callout.querySelector(".sk-callout__actions")?.textContent).toContain("Review plan");
  });
});
