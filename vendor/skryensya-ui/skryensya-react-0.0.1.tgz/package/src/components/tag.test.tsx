import { fireEvent, render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { tagEvents } from "@skryensya/core/tag";
import { Tag } from "./tag.js";

describe("Tag", () => {
  it("serializes its appearance on both hosts, plain by default", () => {
    const ui = render(
      <>
        <Tag>Plain</Tag>
        <Tag appearance="brutalist" href="#x">Brutalist</Tag>
      </>,
    );
    expect(ui.getByText("Plain").closest(".sk-tag")?.getAttribute("data-appearance")).toBe("plain");
    expect(ui.getByText("Brutalist").closest("a")?.getAttribute("data-appearance")).toBe("brutalist");
  });

  it("carries its tone and label", () => {
    const ui = render(<Tag tone="accent">tokens</Tag>);
    const tag = ui.getByText("tokens").closest(".sk-tag");
    expect(tag?.getAttribute("data-tone")).toBe("accent");
  });

  it("exposes a named remove control only when removable is set", () => {
    const onRemove = vi.fn();
    const ui = render(
      <Tag onRemove={onRemove} removable removeLabel="Remove tokens">
        tokens
      </Tag>,
    );
    fireEvent.click(ui.getByLabelText("Remove tokens"));
    expect(onRemove).toHaveBeenCalledOnce();

    const plain = render(<Tag>tokens</Tag>);
    expect(plain.container.querySelector("button")).toBeNull();

    const handlerOnly = render(<Tag onRemove={() => {}}>tokens</Tag>);
    expect(handlerOnly.container.querySelector("button")).toBeNull();
  });

  it("dispatches the contract remove event on the host when the control is used", () => {
    const onEvent = vi.fn();
    const ui = render(
      <Tag removable removeLabel="Remove tokens">
        tokens
      </Tag>,
    );
    const host = ui.getByText("tokens").closest(".sk-tag");
    host?.addEventListener(tagEvents.remove, onEvent);
    fireEvent.click(ui.getByLabelText("Remove tokens"));
    expect(onEvent).toHaveBeenCalledOnce();
  });

  it("renders a navigable tag as a link and never as dismissible", () => {
    const ui = render(
      <Tag href="/topics/design" tone="accent">
        design
      </Tag>,
    );
    const link = ui.getByRole("link", { name: "design" });
    expect(link.getAttribute("href")).toBe("/topics/design");
    expect(link.className).toContain("sk-tag");
    expect(link.className).toContain("sk-interactive");
    expect(link.getAttribute("data-tone")).toBe("accent");
    expect(link.hasAttribute("data-removable")).toBe(false);
    expect(link.querySelector("button")).toBeNull();
  });

  it("removes with a real small icon-only button, not a lookalike", () => {
    const ui = render(
      <Tag removable removeLabel="Remove tokens">
        tokens
      </Tag>,
    );
    const remove = ui.getByLabelText("Remove tokens");
    // The whole point of the composition: hover/press/focus and the 44px hit area are the button's.
    expect(remove.className).toContain("sk-button");
    expect(remove.className).toContain("sk-interactive");
    expect(remove.getAttribute("data-size")).toBe("sm");
    expect(remove.getAttribute("data-variant")).toBe("ghost");
    expect(remove.hasAttribute("data-icon-only")).toBe(true);
    expect(remove.querySelector("svg")).not.toBeNull();
  });
});
