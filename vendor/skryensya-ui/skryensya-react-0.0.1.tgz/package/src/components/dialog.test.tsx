import { fireEvent, render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Dialog } from "./dialog.js";

/*
 * Dialog has no machine on purpose: the behaviour is the platform's. So what there is to test is the
 * anatomy, and above all that closing stays a `<form method="dialog">` submit rather than an onClick,
 * which is what makes the box work before any script runs and lets the opener read `returnValue`.
 */
describe("Dialog", () => {
  // Rendered open throughout: a closed `<dialog>` is inert, so nothing inside it has a role to
  // query, which is the platform doing its half of this contract.
  it("serializes its appearance on the dialog, plain by default", () => {
    const plain = render(<Dialog title="Plain">Body</Dialog>);
    expect(plain.container.querySelector("dialog")?.getAttribute("data-appearance")).toBe("plain");
    const frosted = render(<Dialog appearance="frosted" title="Frosted">Body</Dialog>);
    expect(frosted.container.querySelector("dialog")?.getAttribute("data-appearance")).toBe("frosted");
  });

  it("closes through the platform's own form rather than a handler", () => {
    const ui = render(
      <Dialog open title="Confirmar">
        Contenido
      </Dialog>,
    );

    const close = ui.getByRole("button", { name: "Close" });
    expect(close.getAttribute("type")).toBe("submit");
    expect(close.getAttribute("value")).toBe("cancel");
    expect(close.closest("form")?.getAttribute("method")).toBe("dialog");
    expect(close.querySelector("svg")?.getAttribute("data-icon")).toBe("close");

    // Painted by the Button contract, so Core stays the only place these values live.
    expect(close.classList.contains("sk-dialog__close")).toBe(true);
    expect(close.classList.contains("sk-button")).toBe(true);
    expect(close.classList.contains("sk-interactive")).toBe(true);
    expect(close.getAttribute("data-icon-only")).toBe("");
    expect(close.getAttribute("data-size")).toBe("sm");
    expect(close.getAttribute("data-variant")).toBe("ghost");
  });

  it("renders the anatomy the stylesheet contracts against", () => {
    const ui = render(
      <Dialog
        className="extra"
        footer={
          <button type="submit" value="ok">
            Aceptar
          </button>
        }
        open
        title="Confirmar"
      >
        Contenido
      </Dialog>,
    );

    const dialog = ui.container.querySelector("dialog")!;
    expect(dialog.classList.contains("sk-dialog")).toBe(true);
    // A className from the consumer joins the part class, it does not replace it.
    expect(dialog.classList.contains("extra")).toBe(true);
    const heading = ui.getByRole("heading", { name: "Confirmar" });
    expect(heading.classList).toContain("sk-dialog__title");
    // `<dialog>` gets no accessible name from a nested heading on its own; the box is only
    // announced as "Confirmar" and not "dialog" because this id relationship exists.
    expect(dialog.getAttribute("aria-labelledby")).toBe(heading.id);
    expect(dialog.querySelector(".sk-dialog__body")?.textContent).toBe("Contenido");

    // The footer is a second dialog form, so its buttons report which one closed the box.
    const footer = dialog.querySelector(".sk-dialog__footer")!;
    expect(footer.tagName).toBe("FORM");
    expect(footer.getAttribute("method")).toBe("dialog");
    expect(footer.querySelector("button")?.getAttribute("value")).toBe("ok");
  });

  it("omits the footer form when there is nothing to put in it", () => {
    const ui = render(<Dialog title="Confirmar">Contenido</Dialog>);
    expect(ui.container.querySelector(".sk-dialog__footer")).toBeNull();
  });

  it("aligns the footer row to the inline-start when footerAlign is start", () => {
    const ui = render(
      <Dialog footer={<button type="submit">OK</button>} footerAlign="start" open title="Confirmar">
        Contenido
      </Dialog>,
    );
    expect(ui.container.querySelector("dialog")?.getAttribute("data-footer-align")).toBe("start");
  });

  it("omits data-footer-align when footerAlign is the default end", () => {
    const ui = render(
      <Dialog footer={<button type="submit">OK</button>} open title="Confirmar">
        Contenido
      </Dialog>,
    );
    expect(ui.container.querySelector("dialog")?.hasAttribute("data-footer-align")).toBe(false);
  });

  it("opts into Dialog Vaul with the enhancer's own mount point", () => {
    const ui = render(
      <Dialog title="Filtros" vaul>
        Contenido
      </Dialog>,
    );
    const dialog = ui.container.querySelector("dialog")!;

    expect(dialog.getAttribute("data-sk-dialog-vaul")).toBe("");
    // `dialog-vaul.css` only ever slides from the bottom, so the edge is not a choice.
    expect(dialog.getAttribute("data-edge")).toBe("block-end");
    expect(dialog.querySelector('[data-part="handle"]')?.getAttribute("aria-hidden")).toBe("true");
  });

  it("keeps a plain dialog free of the sheet's attributes", () => {
    const ui = render(<Dialog title="Confirmar">Contenido</Dialog>);
    const dialog = ui.container.querySelector("dialog")!;

    expect(dialog.hasAttribute("data-sk-dialog-vaul")).toBe(false);
    expect(dialog.hasAttribute("data-edge")).toBe(false);
    expect(dialog.querySelector('[data-part="handle"]')).toBeNull();
  });

  it("becomes an alert dialog with role, aria-modal and aria-describedby wired to the body", () => {
    const ui = render(
      <Dialog alert open title="Eliminar cuenta">
        Esta acción no se puede deshacer.
      </Dialog>,
    );

    const dialog = ui.container.querySelector("dialog")!;
    expect(dialog.getAttribute("role")).toBe("alertdialog");
    expect(dialog.getAttribute("aria-modal")).toBe("true");
    const body = dialog.querySelector(".sk-dialog__body")!;
    expect(dialog.getAttribute("aria-describedby")).toBe(body.id);
    expect(body.textContent).toBe("Esta acción no se puede deshacer.");
  });

  it("keeps a plain dialog free of the alert dialog's role and description wiring", () => {
    const ui = render(<Dialog title="Confirmar">Contenido</Dialog>);
    const dialog = ui.container.querySelector("dialog")!;

    expect(dialog.hasAttribute("role")).toBe(false);
    expect(dialog.hasAttribute("aria-modal")).toBe(false);
    expect(dialog.hasAttribute("aria-describedby")).toBe(false);
    expect(dialog.querySelector(".sk-dialog__body")?.hasAttribute("id")).toBe(false);
  });

  it("forwards the platform's own open attribute", () => {
    const ui = render(
      <Dialog closeLabel="Descartar" open title="Confirmar">
        Contenido
      </Dialog>,
    );

    expect(ui.container.querySelector("dialog")?.open).toBe(true);
    expect(ui.getByRole("button", { name: "Descartar" })).toBeTruthy();
  });

  it("wraps Tab at the ends once it is open modally", () => {
    const ui = render(
      <Dialog footer={<button value="ok">Aceptar</button>} title="Confirmar">
        Contenido
      </Dialog>,
    );
    const dialog = ui.container.querySelector("dialog")!;
    dialog.showModal();
    const first = ui.getByRole("button", { name: "Close" });
    const last = ui.getByRole("button", { name: "Aceptar" });

    last.focus();
    fireEvent.keyDown(last, { key: "Tab" });
    expect(document.activeElement).toBe(first);
    fireEvent.keyDown(first, { key: "Tab", shiftKey: true });
    expect(document.activeElement).toBe(last);

    dialog.close();
    ui.unmount();
  });
});
