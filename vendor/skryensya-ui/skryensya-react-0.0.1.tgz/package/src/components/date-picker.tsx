import {
  datePickerContract,
  datePickerEvents,
  datePickerParts,
  defaultContentLabel,
  defaultTriggerLabel,
} from "@skryensya/core/date-picker";
import type { SignatureOptionsOf } from "@skryensya/core/contract";
import {
  calendarParts,
  defaultDayLabel,
  defaultNextTriggerLabel,
  defaultPrevTriggerLabel,
  defaultViewTriggerLabel,
  unusedIntlTranslations,
} from "@skryensya/core/calendar";
import type { DateValue, DateView, DayTableCellState } from "@skryensya/core/calendar";
import { datePicker } from "@skryensya/core/machines";
import { normalizeProps, Portal, useMachine } from "@zag-js/react";
import { useId, useRef, type ReactNode, type RefObject } from "react";
import { useAnchored } from "./anchored.js";
import { asDate, asDates, CalendarBody } from "./calendar.js";
import { Icon } from "./icon.js";

/* Derived, never restated: the default lives in the contract. */
const { clearLabel: clearLabelOption, locale: localeOption, selectionMode: selectionModeOption, timeZone: timeZoneOption } = datePickerContract.options;

// `selectionMode` comes from the contract, so Core stays the only place its values are defined.
export type DatePickerProps = Pick<
  SignatureOptionsOf<typeof datePickerContract, "DatePicker">,
  "selectionMode" | "appearance"
> & {
  /** Where the popover is portalled. Absent it goes to the body: see `ComboboxProps.container`. */
  container?: RefObject<HTMLElement>;
  id?: string;
  name?: string;
  /** Names the field. Contract slot is text-only. */
  label?: string;
  locale?: string;
  timeZone?: string;
  /* Dates as `DateValue` OR as the ISO strings authored markup carries: see `CalendarProps`. */
  value?: readonly (DateValue | string)[] | string;
  defaultValue?: readonly (DateValue | string)[] | string;
  min?: DateValue | string;
  max?: DateValue | string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  invalid?: boolean;
  placeholder?: string;
  triggerIcon?: ReactNode;
  previousIcon?: ReactNode;
  nextIcon?: ReactNode;
  clearLabel?: string;
  /** Accessible name for the calendar-icon trigger, by open state. Default is locale-aware. */
  triggerLabel?: (open: boolean) => string;
  /** Accessible name for the popover holding the calendar. Default is locale-aware. */
  contentLabel?: string;
  /** Accessible name for a day cell, by state. Default is locale-aware. */
  dayLabel?: (state: DayTableCellState) => string;
  /** Accessible name for the day/month/year view-switch button. */
  viewTriggerLabel?: (view: DateView) => string;
  /** Accessible name for "go back". Previous month/year/decade depending on the open view. */
  prevTriggerLabel?: (view: DateView) => string;
  /** Accessible name for "go forward". Next month/year/decade depending on the open view. */
  nextTriggerLabel?: (view: DateView) => string;
  onValueChange?: (details: { value: string[] }) => void;
};

/*
 * DATE PICKER: the editable field (label, input, trigger, clear) plus a popover. The calendar
 * chrome inside the popover is `CalendarBody`, the same component `Calendar` (./calendar.tsx)
 * renders standalone: DatePicker never re-implements the grid, it only supplies the machine
 * instance (popover-mode, not inline) and the field around it.
 */
export function DatePicker({
  appearance,
  clearLabel = clearLabelOption.default,
  container,
  contentLabel,
  dayLabel,
  defaultValue,
  disabled,
  id,
  invalid,
  label,
  locale = localeOption.default,
  max,
  min,
  name,
  nextIcon,
  nextTriggerLabel,
  onValueChange,
  placeholder,
  prevTriggerLabel,
  previousIcon,
  readOnly,
  required,
  selectionMode = selectionModeOption.default,
  timeZone = timeZoneOption.default,
  triggerIcon,
  triggerLabel,
  value,
  viewTriggerLabel,
}: DatePickerProps) {
  const generatedId = useId();
  const rootRef = useRef<HTMLDivElement>(null);
  const service = useMachine(datePicker.machine, {
    id: id ?? generatedId,
    name,
    locale,
    timeZone,
    selectionMode,
    value: asDates(value),
    defaultValue: asDates(defaultValue),
    min: asDate(min),
    max: asDate(max),
    disabled,
    readOnly,
    required,
    invalid,
    fixedWeeks: true,
    translations: {
      ...unusedIntlTranslations(),
      trigger: triggerLabel ?? defaultTriggerLabel(locale),
      content: contentLabel ?? defaultContentLabel(locale),
      dayCell: dayLabel ?? defaultDayLabel(locale),
      viewTrigger: viewTriggerLabel ?? defaultViewTriggerLabel(locale),
      prevTrigger: prevTriggerLabel ?? defaultPrevTriggerLabel(locale),
      nextTrigger: nextTriggerLabel ?? defaultNextTriggerLabel(locale),
    },
    onValueChange(details) {
      const next = { value: details.valueAsString };
      onValueChange?.(next);
      rootRef.current?.dispatchEvent(
        new CustomEvent(datePickerEvents.valueChange, { bubbles: true, detail: next }),
      );
    },
  });
  const api = datePicker.connect(service, normalizeProps);

  /* The anchor is the whole control (input + buttons), not the calendar button: the panel lines up with
   * the field, which is what the calendar is editing. */
  const anchor = useAnchored(id ?? generatedId);
  const inputCount = selectionMode === "range" ? 2 : 1;

  return (
    <div
      {...api.getRootProps()}
      className={datePickerParts.root}
      data-appearance={appearance}
      data-selection-mode={selectionMode}
      data-sk-date-picker=""
      ref={rootRef}
    >
      {label ? (
        <label {...api.getLabelProps()} className={datePickerParts.label}>
          {label}
        </label>
      ) : null}
      <div {...api.getControlProps()} {...anchor.anchor(datePickerParts.control)}>
        {Array.from({ length: inputCount }, (_, index) => (
          <input
            {...api.getInputProps({ index })}
            className={datePickerParts.input}
            key={index}
            placeholder={placeholder}
          />
        ))}
        {/* Rendered-and-hidden, not conditional: the enhancer patches authored markup and can only
            toggle `hidden`, so that is what the contract's template can say. */}
        <button
          {...api.getClearTriggerProps()}
          aria-label={clearLabel}
          className={`${datePickerParts.clear} sk-button sk-interactive`}
          data-icon-only=""
          data-size="sm"
          data-variant="ghost"
          hidden={api.value.length === 0}
          type="button"
        >
          <Icon name="close" size="sm" />
        </button>
        <button
          {...api.getTriggerProps()}
          className={`${datePickerParts.trigger} sk-button sk-interactive`}
          data-icon-only=""
          data-size="sm"
          data-variant="ghost"
          type="button"
        >
          {triggerIcon ?? <Icon name="calendar" size="sm" />}
        </button>
      </div>
      <Portal container={container}>
        <div {...anchor.positioner(api.getPositionerProps(), datePickerParts.positioner)}>
          <div
            {...api.getContentProps()}
            className={`${datePickerParts.content} ${calendarParts.root}`}
          >
            <CalendarBody
              api={api}
              locale={locale}
              nextIcon={nextIcon}
              previousIcon={previousIcon}
            />
          </div>
        </div>
      </Portal>
    </div>
  );
}

export type NativeDatePickerProps = {
  /** How the field is drawn: `plain`, `brutalist` or `frosted`. Absent means plain. */
  appearance?: (typeof datePickerContract.options.appearance.values)[number];
  /** Names the field. Contract slot is text-only and required. */
  label: string;
  name?: string;
  locale?: string;
  id?: string;
  /** Starting date, ISO. Contract option; React also accepts controlled `value`. */
  value?: string;
  defaultValue?: string;
  min?: string;
  max?: string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
};

/*
 * THE NATIVE DATE FIELD: the layer that works with no script at all.
 *
 * A real `<input type="date">` inside the same field chrome, so the enhanced control and this one
 * read as the SAME field rather than two designs. The browser owns the picker, the keyboard, the
 * locale format and the form; the system contributes the label wiring and the box around it.
 *
 * Its own signature rather than an option on `DatePicker`, for the reason `Select.native` is one:
 * choosing between them is choosing who owns the behaviour, and no flag should be able to stand in
 * for that decision.
 */
export function NativeDatePicker({
  appearance,
  defaultValue,
  disabled,
  id,
  label,
  locale,
  max,
  min,
  name,
  readOnly,
  required,
  value,
}: NativeDatePickerProps) {
  const generatedId = useId();
  const inputId = id ?? generatedId;

  return (
    <div className={datePickerParts.root} data-appearance={appearance}>
      {/* Named through `aria-labelledby` rather than `for`/`id`: see the contract, where the
          reason is the shared stage rather than the markup. */}
      <label className={datePickerParts.label} id={`${inputId}-label`}>
        {label}
      </label>
      <div className={datePickerParts.control}>
        <input
          aria-labelledby={`${inputId}-label`}
          className={datePickerParts.input}
          defaultValue={value === undefined ? defaultValue : undefined}
          disabled={disabled}
          lang={locale}
          max={max}
          min={min}
          name={name}
          readOnly={readOnly}
          required={required}
          type="date"
          value={value}
        />
      </div>
    </div>
  );
}
