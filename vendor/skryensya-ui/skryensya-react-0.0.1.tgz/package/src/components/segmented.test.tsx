import { fireEvent, render } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { SegmentedControl } from "./segmented.js";

const options = [
  { value: "day", label: "Day" },
  { value: "week", label: "Week" },
  { value: "month", label: "Month" },
];

describe("SegmentedControl", () => {
  it("is a radiogroup with exactly one checked option", () => {
    const ui = render(<SegmentedControl defaultValue="week" label="Range" options={options} />);
    expect(ui.getByRole("radiogroup")).toBeTruthy();
    const selected = ui.getByRole("radio", { checked: true });
    expect(selected.textContent).toBe("Week");
    expect(selected.classList.contains("sk-interactive")).toBe(true);
  });

  it("serializes its appearance on the root, plain by default", () => {
    const plain = render(<SegmentedControl defaultValue="week" label="Plain" options={options} />);
    expect(plain.getByRole("radiogroup", { name: "Plain" }).getAttribute("data-appearance")).toBe("plain");
    const tactile = render(<SegmentedControl appearance="tactile" defaultValue="week" label="Tactile" options={options} />);
    expect(tactile.getByRole("radiogroup", { name: "Tactile" }).getAttribute("data-appearance")).toBe("tactile");
  });

  it("serializes its size on the root, sm by default, on Button's scale", () => {
    const small = render(<SegmentedControl defaultValue="week" label="Small" options={options} />);
    expect(small.getByRole("radiogroup", { name: "Small" }).getAttribute("data-size")).toBe("sm");
    const large = render(<SegmentedControl size="lg" defaultValue="week" label="Large" options={options} />);
    expect(large.getByRole("radiogroup", { name: "Large" }).getAttribute("data-size")).toBe("lg");
  });

  it("names the radiogroup, per WAI's Radio Group pattern", () => {
    const ui = render(<SegmentedControl defaultValue="week" label="Range" options={options} />);
    expect(ui.getByRole("radiogroup", { name: "Range" })).toBeTruthy();
  });

  it("moves its selection indicator to the newly checked option", () => {
    const ui = render(<SegmentedControl defaultValue="day" label="Range" options={options} />);
    const month = ui.getByRole("radio", { name: "Month" });
    Object.defineProperties(month, {
      offsetHeight: { configurable: true, value: 32 },
      offsetLeft: { configurable: true, value: 104 },
      offsetTop: { configurable: true, value: 4 },
      offsetWidth: { configurable: true, value: 76 },
    });

    fireEvent.click(month);

    const indicator = ui.container.querySelector<HTMLElement>(".sk-segmented__indicator");
    if (!indicator) throw new Error("Segmented control did not render an indicator");
    expect(indicator.style.transform).toBe("translate3d(104px, 4px, 0)");
    expect(indicator.style.inlineSize).toBe("76px");
    expect(indicator.style.blockSize).toBe("32px");
  });

  it("reports the selected value when uncontrolled", () => {
    const onValueChange = vi.fn();
    const onDom = vi.fn();
    const ui = render(
      <SegmentedControl defaultValue="day" label="Range" onValueChange={onValueChange} options={options} />,
    );
    ui.container.firstElementChild?.addEventListener("sk:segmentedvaluechange", onDom);
    fireEvent.click(ui.getByText("Month"));
    expect(onValueChange).toHaveBeenCalledWith("month");
    expect(ui.getByRole("radio", { checked: true }).textContent).toBe("Month");
    expect(onDom).toHaveBeenCalledTimes(1);
    expect((onDom.mock.calls[0]![0] as CustomEvent).detail).toEqual({ value: "month" });
  });

  it("stamps the contract mount marks on root and options", () => {
    const ui = render(<SegmentedControl defaultValue="week" label="Range" options={options} />);
    const root = ui.getByRole("radiogroup");
    expect(root.hasAttribute("data-sk-segmented")).toBe(true);
    expect(ui.container.querySelectorAll("[data-sk-segmented-option]")).toHaveLength(3);
  });

  it("selects the next enabled option with an arrow key", () => {
    const ui = render(
      <SegmentedControl
        defaultValue="day"
        label="Range"
        options={[...options, { value: "year", label: "Year", disabled: true }]}
      />,
    );
    const day = ui.getByRole("radio", { name: "Day" });
    const week = ui.getByRole("radio", { name: "Week" });

    day.focus();
    fireEvent.keyDown(day, { key: "ArrowRight" });

    expect(document.activeElement).toBe(week);
    expect(week.getAttribute("aria-checked")).toBe("true");
    expect(week.getAttribute("tabindex")).toBe("0");
  });
});
