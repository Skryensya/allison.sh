import { fireEvent, render } from "@testing-library/react";
import { describe, expect, it } from "vitest";
import { Toolbar } from "./toolbar.js";

/*
 * No test file existed for this binding before. Confirmed while auditing against the WAI-ARIA APG
 * toolbar pattern (docs/aria-apg-audit.md). That gap is exactly why this binding had DIVERGED from
 * `toolbar.ts` (vanilla) without anyone noticing: no `event.defaultPrevented` guard, and no
 * `tabindex`-based filtering to treat a nested composite as ONE stop. Both fixed in this same
 * session, see the file's own comment.
 */
function Fixture() {
  return (
    <Toolbar label="Formato">
      <button type="button" id="bold">B</button>
      <button type="button" id="italic">I</button>
      <button type="button" id="disabled-native" disabled>D</button>
      <div role="radiogroup" aria-label="Alineación">
        <button type="button" id="align-left" role="radio" aria-checked="true" tabIndex={0}>←</button>
        <button type="button" id="align-center" role="radio" aria-checked="false" tabIndex={-1}>↔</button>
        <button type="button" id="align-right" role="radio" aria-checked="false" tabIndex={-1}>→</button>
      </div>
      <button type="button" id="underline">U</button>
    </Toolbar>
  );
}

describe("Toolbar React contracts", () => {
  it("serializes its appearance on the bar, plain by default", () => {
    const plain = render(<Toolbar label="Plain"><button type="button">A</button></Toolbar>);
    expect(plain.getByRole("toolbar", { name: "Plain" }).getAttribute("data-appearance")).toBe("plain");
    const tactile = render(<Toolbar appearance="tactile" label="Tactile"><button type="button">A</button></Toolbar>);
    expect(tactile.getByRole("toolbar", { name: "Tactile" }).getAttribute("data-appearance")).toBe("tactile");
  });

  it("sets role and aria-orientation", () => {
    const ui = render(<Fixture />);
    const toolbar = ui.getByRole("toolbar", { name: "Formato" });
    expect(toolbar.hasAttribute("data-sk-toolbar")).toBe(true);
    expect(toolbar.getAttribute("aria-orientation")).toBe("horizontal");
  });

  it("forwards arbitrary attrs to the root, same as ToolbarGroup already did. Vanilla always had this via the emitted template", () => {
    const ui = render(
      <Toolbar data-docs-example="true" label="Formato">
        <button type="button">B</button>
      </Toolbar>,
    );
    expect(ui.getByRole("toolbar").getAttribute("data-docs-example")).toBe("true");
  });

  it("Right/Left move between controls, skipping a NATIVELY disabled one", () => {
    const ui = render(<Fixture />);
    ui.getByText("B").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("I"));
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("←"));
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowLeft" });
    expect(document.activeElement).toBe(ui.getByText("I"));
  });

  it("loops by default from the last control back to the first", () => {
    const ui = render(<Fixture />);
    ui.getByText("U").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("B"));
  });

  it("does not loop when loopFocus is false", () => {
    const ui = render(
      <Toolbar label="Formato" loopFocus={false}>
        <button type="button">B</button>
        <button type="button">I</button>
      </Toolbar>,
    );
    ui.getByText("I").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("I"));
  });

  it("Home/End jump to the first/last control", () => {
    const ui = render(<Fixture />);
    ui.getByText("I").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "Home" });
    expect(document.activeElement).toBe(ui.getByText("B"));
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "End" });
    expect(document.activeElement).toBe(ui.getByText("U"));
  });

  it("treats a nested composite (radiogroup) as a SINGLE stop. The bug this session found and fixed", () => {
    const ui = render(<Fixture />);
    ui.getByText("I").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("←")); // the radiogroup's own tabindex=0 member
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(document.activeElement).toBe(ui.getByText("U")); // skips ↔/→ entirely, unlike before the fix
  });

  it("leaves exactly one tab stop in the bar, and a composite's other members out of it", () => {
    const ui = render(<Fixture />);
    const toolbar = ui.getByRole("toolbar");
    expect([...toolbar.querySelectorAll('[tabindex="0"]')].map((node) => node.textContent)).toEqual(["B"]);
    expect(ui.getByText("↔").getAttribute("tabindex")).toBe("-1");
  });

  it("moves the tab stop with focus and keeps it across a re-render", () => {
    const ui = render(<Fixture />);
    ui.getByText("B").focus();
    fireEvent.keyDown(ui.getByRole("toolbar"), { key: "ArrowRight" });
    expect(ui.getByText("I").getAttribute("tabindex")).toBe("0");
    ui.rerender(<Fixture />);
    expect(ui.getByText("I").getAttribute("tabindex")).toBe("0");
    expect(ui.getByText("B").getAttribute("tabindex")).toBe("-1");
  });

  it("defers to a composite child that already handled the key itself (defaultPrevented). The other half of the bug", () => {
    const ui = render(<Fixture />);
    const alignCenter = ui.getByText("↔");
    alignCenter.tabIndex = 0;
    alignCenter.focus();
    alignCenter.addEventListener("keydown", (event) => event.preventDefault());
    fireEvent.keyDown(alignCenter, { key: "ArrowRight" });
    expect(document.activeElement).toBe(alignCenter);
  });
});
