import type { ComponentContract } from "./contract.js";
/*
 * COMMAND PALETTE, a searchable listbox inside a native Dialog.
 *
 * Builds on Dialog (ADR-19): `<dialog class="sk-dialog sk-command-palette">` + showModal(). The
 * shell (border, radius, surface, elevation, backdrop) is Dialog's; this file owns the search row,
 * results listbox, empty state and footer chrome.
 *
 * The consumer authors the index (JSON) and the option markup contract; the Vanilla enhancer filters
 * and drives aria-activedescendant. Interaction paint stays on `sk-interactive` where present.
 */
type CommandPaletteEntryBase = {
  label: string;
  aliases?: readonly string[];
  /** Context shown beside the label (section › group, path, etc.). */
  context?: string;
  section?: string;
  group?: string;
};

/** A destination: activating it navigates to `href`. */
export type CommandPaletteLink = CommandPaletteEntryBase & { href: string; command?: undefined };

/**
 * An action rather than a place: activating it closes the palette and fires
 * `sk:commandpalettecommand` (React: `onCommand`) with `command`, and the host does the rest.
 *
 * HIDDEN UNTIL ASKED FOR. A command is listed only once the query starts with
 * `COMMAND_PALETTE_COMMAND_PREFIX` ("/"), and a query that does not start with it lists only links.
 * Someone searching for "tour" is looking for the Tour page, not starting one; typing "/" first is
 * the explicit "I want to DO something" that the same word cannot say on its own.
 */
export type CommandPaletteCommand = CommandPaletteEntryBase & { command: string; href?: undefined };

export type CommandPaletteEntry = CommandPaletteLink | CommandPaletteCommand;

/** What a query starts with to ask for commands instead of destinations. */
export const COMMAND_PALETTE_COMMAND_PREFIX = "/";

export function isCommandPaletteCommand(entry: CommandPaletteEntry): entry is CommandPaletteCommand {
  return typeof entry.command === "string";
}

export const commandPaletteParts = {
  root: "sk-command-palette",
  search: "sk-command-palette__search",
  input: "sk-command-palette__input",
  close: "sk-command-palette__close",
  list: "sk-command-palette__list",
  option: "sk-command-palette__option",
  optionLabel: "sk-command-palette__option-label",
  optionContext: "sk-command-palette__option-context",
  empty: "sk-command-palette__empty",
  footer: "sk-command-palette__footer",
} as const;

export type CommandPalettePart = keyof typeof commandPaletteParts;
export type CommandPalettePartClass = (typeof commandPaletteParts)[CommandPalettePart];

export const commandPaletteAttrs = {
  root: "data-sk-command-palette",
  open: "data-sk-command-palette-open",
  input: "data-sk-command-palette-input",
  list: "data-sk-command-palette-list",
  empty: "data-sk-command-palette-empty",
  index: "data-sk-command-palette-index",
  hotkey: "data-sk-command-palette-hotkey",
  hint: "data-sk-command-palette-hint",
} as const;

export const commandPaletteEvents = {
  /** On the root, bubbling, when a command entry is activated. Detail: `{ command, entry }`. */
  command: "sk:commandpalettecommand",
} as const;

export type CommandPaletteCommandEventDetail = {
  command: string;
  entry: CommandPaletteCommand;
};

export type CommandPaletteAttr = keyof typeof commandPaletteAttrs;
export type CommandPaletteAttrName = (typeof commandPaletteAttrs)[CommandPaletteAttr];

export function normalizeCommandPaletteQuery(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

/** Rank a query against an entry. Null = no match; lower is better (prefix → contains → context). */
export function scoreCommandPaletteEntry(
  entry: CommandPaletteEntry,
  query: string,
): number | null {
  const names = [entry.command ?? "", entry.label, ...(entry.aliases ?? [])]
    .filter(Boolean)
    .map(normalizeCommandPaletteQuery);
  const context = normalizeCommandPaletteQuery(
    entry.context ?? `${entry.section ?? ""} ${entry.group ?? ""}`,
  );
  if (names.some((name) => name.startsWith(query))) return 0;
  if (names.some((name) => name.includes(query))) return 1;
  if (context.includes(query)) return 2;
  return null;
}

export function filterCommandPaletteEntries(
  index: readonly CommandPaletteEntry[],
  query: string,
): CommandPaletteEntry[] {
  const asksForCommands = query.trimStart().startsWith(COMMAND_PALETTE_COMMAND_PREFIX);
  const pool = index.filter((entry) => isCommandPaletteCommand(entry) === asksForCommands);
  const q = normalizeCommandPaletteQuery(
    asksForCommands ? query.trimStart().slice(COMMAND_PALETTE_COMMAND_PREFIX.length) : query,
  );
  if (q === "") return pool;
  return pool
    .map((entry) => ({ entry, rank: scoreCommandPaletteEntry(entry, q) }))
    .filter((row): row is { entry: CommandPaletteEntry; rank: number } => row.rank !== null)
    .sort((a, b) => a.rank - b.rank)
    .map((row) => row.entry);
}

export function commandPaletteOptionContext(entry: CommandPaletteEntry): string {
  if (entry.context) return entry.context;
  if (entry.section && entry.group) return `${entry.section} › ${entry.group}`;
  return entry.section ?? entry.group ?? "";
}

/*
 * COMMAND PALETTE, the contract: the last of the ten pages that had none.
 *
 * The enhancer shipped with no React counterpart, so this could not be a contract at all: one
 * binding is not a contract, it is a script. Writing the missing half is what made it possible, the
 * same way it did for `dialog`.
 *
 * THE LIST IS EMPTY IN THE MARKUP, on purpose: the enhancer only fills it when the palette opens,
 * and the React half copies that rather than improving on it. What a composition supplies is the
 * INDEX, and the enhancer reads that from a JSON script the way authored markup has to.
 *
 * `aria-expanded` is NOT written here, and that is a fix rather than an omission. The authored
 * markup on the docs page hardcoded `aria-expanded="true"`, a combobox announcing an expanded
 * popup over an empty listbox, which axe reports and a screen reader would act on. Both bindings set
 * it when there is something to expand; neither claims it at rest.
 */
export const commandPaletteContract = {
  id: "command-palette",
  category: "actions",
  css: "@skryensya/core/components/command-palette.css",
  parts: commandPaletteParts,
  /* Result rows are binding-filled on open; emit list stays empty. */
  systemOwned: ["option", "optionLabel", "optionContext"],
  hooks: [
    "--sk-command-palette-border-color",
    "--sk-command-palette-footer-bg",
    "--sk-command-palette-footer-fg",
    "--sk-command-palette-inline-size",
    "--sk-command-palette-list-max-block-size",
    "--sk-command-palette-list-min-block-size",
    "--sk-command-palette-option-bg-selected",
  ],
  /*
   * Default-ON Vaul lives in `patterns/dialog-vaul.css`. Naming it here is what lets
   * `sheetsForTree` load the sheet, `also: sk-dialog` discovers dialog.css, not the Vaul pattern
   * (same shape as Dialog's own hookSheets).
   */
  hookSheets: ["@skryensya/core/patterns/dialog-vaul.css"],
  events: commandPaletteEvents,
  eventDetails: {
    command: {
      detail: { command: "string", entry: "CommandPaletteCommand" },
      reactProp: "onCommand",
      reactDetail: "(command: string, entry: CommandPaletteCommand)",
      source: "root",
    },
  },

  options: {
    /*
     * HOW THE PALETTE IS DRAWN, Dialog's appearance axis, painted by Dialog's own sheet since the
     * root is a .sk-dialog: brutalist a black edge and hard offset, frosted a see-through panel
     * (opaque wherever the material cannot be trusted). No tactile.
     */
    appearance: {
      type: "enum",
      values: ["plain", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
    /** Names the dialog for anyone who cannot see it. An option, not a slot: both bindings put it
     * on `aria-label`, and a visually-hidden element would be a second way to say one thing. */
    label: { type: "string", attr: "aria-label" },
    /** The dialog's own id: the trigger points at it and the index is keyed to it. */
    paletteId: { type: "string", attr: "id", prop: "id" },
    /** What the closing control announces. Lives on the close button as `aria-label`, same as Dialog. */
    closeLabel: { type: "string", default: "Close", attr: "aria-label" },
    /** Shown in the search field while it is empty. */
    placeholder: { type: "string", default: "Search…", attr: "placeholder" },
    /** What the empty state says once a filter matches nothing. */
    emptyLabel: { type: "string", default: "No results.", attr: "data-empty-label", machineInput: true },
    /** Rendered already open, non-modally: the platform's attribute, same as `Dialog.open`. */
    open: { type: "boolean", default: false, attr: "open", trueValue: "" },
    /**
     * A block-end sheet below the desktop breakpoint, and ON BY DEFAULT: the same `<dialog>` opted
     * into Dialog Vaul (`patterns/dialog-vaul.css`), with drag-to-dismiss from the handle.
     *
     * Default ON because a palette is the one dialog a phone opens with a thumb from the bottom of the
     * screen, and a centred box there puts the search field under the keyboard and the results off the
     * top. It was already what the documentation shipped, by writing the attribute by hand in its own
     * markup - which is how a behaviour ends up true of one site and false of the component. Same
     * attribute as `Dialog.vaul`, so the sheet, the enhancer's mount point and the drag are one
     * mechanism, not a palette-shaped copy. `false` keeps the centred box at every width.
     */
    vaul: { type: "boolean", default: true, attr: "data-sk-dialog-vaul", trueValue: "" },
    /**
     * The index, JSON-encoded: a demo's ONLY way to seed one, since a usage tree names contracts
     * and signatures and has no channel for a literal `<script>`. No `attr`: it never lands on an
     * element as a value, only as the JSON script's text (below) or, renamed to `items`, as
     * React's own prop. Machine input on both sides, same as `emptyLabel`.
     */
    entries: { type: "string", prop: "items", machineInput: true },
  },

  signatures: {
    CommandPalette: {
      intent: ["command-palette", "search-everything", "keyboard-first-navigation"],
      host: { element: "dialog" },
      mount: commandPaletteAttrs.root,
      options: [
        "label",
        "paletteId",
        "closeLabel",
        "placeholder",
        "emptyLabel",
        "open",
        "vaul",
        "entries",
        "appearance",
      ],
      requires: ["label", "paletteId"],
      /** Extra a11y; palette id is the paletteId option (not forwarded). */
      forward: ["aria-*"],
      compose: [
        { of: "button", sheets: ["@skryensya/core/components/button.css"], systemOwned: true },
        { of: "dialog", sheets: ["@skryensya/core/components/dialog.css"], systemOwned: true },
        { of: "icon", systemOwned: true },
      ],
      slots: {
        /** Keyboard-hint strip under the list. Optional: demos and React pass it; Vanilla authors it. */
        footer: { accepts: "node" },
      },
      template: {
        element: "dialog",
        part: "root",
        also: ["sk-dialog"],
        host: true,
        attrsWhen: [
          {
            option: "entries",
            given: true,
            attrs: { [commandPaletteAttrs.index]: "sk-command-palette-index" },
          },
          { option: "vaul", given: true, attrs: { "data-edge": "block-end" } },
        ],
        children: [
          /*
           * The grab handle Dialog Vaul drags from (`[data-part="handle"]`, a DIRECT child: the
           * enhancer looks for `:scope > [data-part="handle"]` so a nested component's own handle can
           * never take the gesture). Always in the markup rather than gated on `vaul`, because a
           * default-ON option is exactly the one `whenGiven` cannot see; `command-palette.css` hides
           * it on a palette that opted out, and `dialog-vaul.css` hides it above the breakpoint.
           */
          { element: "div", attrs: { "aria-hidden": "true", "data-part": "handle" } },
          {
            element: "div",
            part: "search",
            children: [
              { element: "span", attrs: { "data-sk-icon": "search", "data-sk-icon-size": "md" } },
              {
                element: "input",
                part: "input",
                mount: commandPaletteAttrs.input,
                options: ["placeholder"],
                attrs: {
                  type: "text",
                  role: "combobox",
                  autocomplete: "off",
                  spellcheck: "false",
                  "aria-expanded": "false",
                  "aria-autocomplete": "list",
                  /* Always points at the listbox, visible or not. WAI's combobox pattern requires
                   * this whether or not the popup happens to be open right now. */
                  "aria-controls": "sk-command-palette-listbox",
                },
              },
              {
                element: "form",
                attrs: { method: "dialog" },
                children: [
                  {
                    element: "button",
                    part: "close",
                    also: ["sk-button", "sk-dialog__close", "sk-interactive"],
                    options: ["closeLabel"],
                    attrs: {
                      type: "submit",
                      value: "cancel",
                      "data-icon-only": "",
                      "data-size": "sm",
                      "data-variant": "ghost",
                    },
                    children: [
                      { element: "span", attrs: { "data-sk-icon": "close", "data-sk-icon-size": "md" } },
                    ],
                  },
                ],
              },
            ],
          },
          {
            /* Empty by construction: the enhancer fills it on open, and so does the React half. */
            element: "ul",
            part: "list",
            also: ["sk-scrollbar"],
            mount: commandPaletteAttrs.list,
            attrs: { role: "listbox", "aria-label": "Resultados", id: "sk-command-palette-listbox" },
          },
          {
            element: "p",
            part: "empty",
            mount: commandPaletteAttrs.empty,
            options: ["emptyLabel"],
            attrs: { hidden: "" },
            textFromOption: "emptyLabel",
          },
          {
            element: "footer",
            part: "footer",
            slot: "footer",
            whenGiven: "footer",
          },
          /*
           * A demo's index, authored the only way a usage tree can: as this signature's own JSON
           * island. Absent unless `entries` was given: a composition with a real, page-owned index
           * still authors its own script the way it always has.
           */
          {
            element: "script",
            whenGiven: "entries",
            attrs: { type: "application/json", id: "sk-command-palette-index" },
            textFromOption: "entries",
          },
        ],
      },
      react: { from: "@skryensya/react/command-palette", name: "CommandPalette" },
    },
  },
} as const satisfies ComponentContract;
