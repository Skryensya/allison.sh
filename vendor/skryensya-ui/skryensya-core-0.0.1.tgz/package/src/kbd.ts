import type { ComponentContract } from "./contract.js";

/*
 * KBD, the contract.
 *
 * A single keyboard key. Static, like Badge: the class and part are ours and permanent; there is no
 * state and no machine, so there is no vanilla enhancer and nothing here but the part name.
 */
export const kbdParts = {
  root: "sk-kbd",
} as const;

export type KbdPart = keyof typeof kbdParts;
export type KbdPartClass = (typeof kbdParts)[KbdPart];

/** Named by ROLE, same as Badge: `accent` is the brand, never a hue. */
export type KbdTone = "neutral" | "accent";

/*
 * A key, on the `<kbd>` element the platform already has for it. One option: whether the key is a
 * physical legend (the default) or an accent-toned label. The element is still the meaning; the
 * tone is only paint.
 */
export const kbdContract = {
  id: "kbd",
  category: "content",
  css: "@skryensya/core/components/kbd.css",
  parts: kbdParts,
  hooks: [
    "--sk-kbd-bg",
    "--sk-kbd-border-color",
    "--sk-kbd-border-width",
    "--sk-kbd-fg",
    "--sk-kbd-font-family",
    "--sk-kbd-font-size",
    "--sk-kbd-line-height",
    "--sk-kbd-min-size",
    "--sk-kbd-padding-x",
    "--sk-kbd-radius",
    "--sk-kbd-shadow",
    "--sk-kbd-wash",
  ],
  options: {
    /*
     * HOW THE KEY IS DRAWN, Button's axis, brutalist alone: a black edge and a small hard offset in
     * place of the keycap's soft depth. No tactile (a legend is never pressed) and no frosted
     * (glass would only cost the legend its contrast).
     */
    appearance: {
      type: "enum",
      values: ["plain", "brutalist"],
      default: "plain",
      attr: "data-appearance",
    },
    tone: {
      type: "enum",
      values: ["neutral", "accent"],
      default: "neutral",
      attr: "data-tone",
    },
  },

  signatures: {
    Kbd: {
      intent: ["keyboard-key", "shortcut", "key-combination"],
      host: { element: "kbd" },
      options: ["tone", "appearance"],
      slots: { children: { accepts: "text", required: true } },
      template: { element: "kbd", part: "root", host: true, slot: "children" },
      react: { from: "@skryensya/react/kbd", name: "Kbd" },
    },
  },
} as const satisfies ComponentContract;
