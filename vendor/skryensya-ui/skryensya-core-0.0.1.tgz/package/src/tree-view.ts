import type { ComponentContract } from "./contract.js";

export type TreeNode = {
  id: string;
  label: string;
  disabled?: boolean;
  children?: readonly TreeNode[];
};

export const treeViewParts = {
  root: "sk-tree-view",
  tree: "sk-tree-view__tree",
  item: "sk-tree-view__item",
  itemIcon: "sk-tree-view__item-icon",
  itemText: "sk-tree-view__item-text",
  branch: "sk-tree-view__branch",
  branchControl: "sk-tree-view__branch-control",
  branchIndicator: "sk-tree-view__branch-indicator",
  branchIcon: "sk-tree-view__branch-icon",
  branchText: "sk-tree-view__branch-text",
  branchContent: "sk-tree-view__branch-content",
} as const;

export const treeViewAttrs = {
  root: "data-sk-tree-view",
  tree: "data-sk-tree-view-tree",
  item: "data-sk-tree-view-item",
  branch: "data-sk-tree-view-branch",
  branchControl: "data-sk-tree-view-branch-control",
  branchIndicator: "data-sk-tree-view-branch-indicator",
  branchText: "data-sk-tree-view-branch-text",
  itemText: "data-sk-tree-view-item-text",
  branchContent: "data-sk-tree-view-branch-content",
} as const;

/** Dispatched on the root by both bindings, with `TreeViewSelectionDetails` / `TreeViewExpandedDetails`. */
export const treeViewEvents = {
  selectionChange: "sk:treeviewselectionchange",
  expandedChange: "sk:treeviewexpandedchange",
} as const;

export type TreeViewSelectionDetails = { selectedValue: string[] };
export type TreeViewExpandedDetails = { expandedValue: string[] };

/**
 * A hierarchy you can walk: files, an org chart, a table of contents.
 *
 * The one family whose data RECURSES. A folder holds folders, and the reason the collection model
 * grew `recursive`. Everything else in the catalogue is a flat list of entries; here an entry's
 * children are entries of the same shape, at any depth, and a template that had to state each level
 * would state them forever.
 *
 * A node is a branch or a leaf, and nobody sets which: it is whether it has children. That is what
 * decides the element, the control, the chevron and the role, so it is asked of the CONTENT rather
 * than of an option.
 *
 * Zag owns `aria-level`, `aria-posinset` and the roving focus, and writes them onto whichever markup
 * it is given, so the authored tree carries structure and the machine carries position.
 */
export const treeViewContract = {
  id: "tree-view",
  category: "navigation",
  css: "@skryensya/core/components/tree-view.css",
  parts: treeViewParts,
  events: treeViewEvents,
  eventDetails: {
    selectionChange: { detail: { selectedValue: "string[]" }, reactProp: "onSelectionChange", source: "root", trigger: "item" },
    expandedChange: { detail: { expandedValue: "string[]" }, reactProp: "onExpandedChange", source: "root", trigger: "branchControl" },
  },
  hooks: [
    "--sk-tree-branch-icon-color",
    "--sk-tree-guide-color",
    "--sk-tree-guide-width",
    "--sk-tree-indent",
    "--sk-tree-indicator-color",
    "--sk-tree-indicator-size",
    "--sk-tree-item-gap",
    "--sk-tree-leaf-icon-color",
    "--sk-tree-node-icon-color",
    "--sk-tree-node-icon-size",
    "--sk-tree-row-gap",
    "--sk-tree-row-inset",
  ],

  options: {
    /** The tree's accessible name. A tree with no name is a list of words with no subject. */
    label: { type: "string", attr: "aria-label", machineInput: true },
    selectionMode: {
      type: "enum",
      values: ["single", "multiple"],
      default: "single",
      attr: "data-selection-mode",
      machineInput: true,
    },
    defaultExpandedValue: { type: "string", attr: "data-expanded-value", machineInput: true, keyOf: { slot: "items", many: true } },
    defaultSelectedValue: { type: "string", attr: "data-selected-value", machineInput: true, keyOf: { slot: "items", many: true } },
  },

  signatures: {
    TreeView: {
      intent: ["tree", "file-explorer", "hierarchy", "nested-list", "folder-structure"],
      host: { element: "div" },
      options: ["label", "selectionMode", "defaultExpandedValue", "defaultSelectedValue"],
      requires: ["label"],
      /** Host id / a11y; label stays the option. */
      forward: ["id", "aria-*"],
      slots: {
        branchIndicator: { accepts: "node" },
        branchIcon: { accepts: "node" },
        leafIcon: { accepts: "node" },
        items: {
          accepts: "items",
          prop: "nodes",
          required: true,
          item: {
            options: {
              /**
               * The node's identity, unique across the WHOLE tree rather than among siblings: the
               * machine addresses nodes by it at any depth, and selection and expansion are
               * expressed in it.
               */
              id: { type: "string", attr: "data-value" },
              /* `data-disabled`, not `disabled`: HTML gives an `<li>` no such attribute, and this is the
                 spelling Zag writes on the node and the stylesheet already selects. */
              disabled: { type: "boolean", default: false, attr: "data-disabled", trueValue: "" },
            },
            slots: {
              label: { accepts: "text", required: true },
              /** Same shape, one level down. A folder holds folders. */
              children: { accepts: "items", recursive: true },
            },
            key: "id",
          },
        },
      },
      mount: "data-sk-tree-view",
      template: {
        element: "div",
        part: "root",
        host: true,
        children: [
          {
            element: "ul",
            part: "tree",
            mount: "data-sk-tree-view-tree",
            children: [
              {
                repeat: "items",
                children: [
                  /*
                   * The shape, written once and named. Everything below points back at this rather
                   * than restating it, which is the only way a fixed template renders a structure
                   * of unbounded depth.
                   */
                  {
                    name: "node",
                    children: [
                      {
                        element: "li",
                        part: "branch",
                        // A branch is a node that HAS children. Nobody sets that; it is the content.
                        whenItemSlotGiven: "children",
                        mount: "data-sk-tree-view-branch",
                        itemOptions: ["id", "disabled"],
                        children: [
                          {
                            element: "button",
                            part: "branchControl",
                            also: ["sk-interactive"],
                            mount: "data-sk-tree-view-branch-control",
                            attrs: { type: "button" },
                            children: [
                              {
                                element: "span",
                                part: "branchIndicator",
                                mount: "data-sk-tree-view-branch-indicator",
                                attrs: { "aria-hidden": "true" },
                                whenGiven: "branchIndicator",
                                slot: "branchIndicator",
                              },
                              /*
                               * NO SLOT, NO TEXT: the span ships empty and the stylesheet draws the
                               * chevron into it (`:not(:has(*))`, tree-view.css). It used to write a
                               * literal "›", which is the one text-glyph fallback left in the system
                               * and the reason this component's own docs showed a thin, undersized
                               * mark next to every other chevron on the page, all real icons: the
                               * character renders in whatever the reader's font ships for that code
                               * point. Treegrid's disclosure already made this move and says the same
                               * thing at its own `mask-image`.
                               */
                              {
                                element: "span",
                                part: "branchIndicator",
                                mount: "data-sk-tree-view-branch-indicator",
                                attrs: { "aria-hidden": "true" },
                                whenMissing: "branchIndicator",
                              },
                              {
                                element: "span",
                                part: "branchIcon",
                                attrs: { "aria-hidden": "true" },
                                whenGiven: "branchIcon",
                                slot: "branchIcon",
                              },
                              { element: "span", part: "branchText", mount: "data-sk-tree-view-branch-text", itemSlot: "label" },
                            ],
                          },
                          {
                            element: "ul",
                            part: "branchContent",
                            mount: "data-sk-tree-view-branch-content",
                            children: [{ repeatItemSlot: "children", recurse: "node" }],
                          },
                        ],
                      },
                      {
                        element: "li",
                        part: "item",
                        also: ["sk-interactive"],
                        whenItemSlotMissing: "children",
                        mount: "data-sk-tree-view-item",
                        itemOptions: ["id", "disabled"],
                        children: [
                          {
                            element: "span",
                            part: "itemIcon",
                            attrs: { "aria-hidden": "true" },
                            whenGiven: "leafIcon",
                            slot: "leafIcon",
                          },
                          { element: "span", part: "itemText", mount: "data-sk-tree-view-item-text", itemSlot: "label" },
                        ],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/tree-view", name: "TreeView" },
    },
  },
} as const satisfies ComponentContract;
