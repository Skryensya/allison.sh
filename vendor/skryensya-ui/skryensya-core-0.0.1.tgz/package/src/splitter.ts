/*
 * SPLITTER. The shared "Window Splitter" behaviour (WAI-ARIA APG), the pure matcher and constants
 * every drag-to-resize handle in this system shares: Sidebar's rail edge, Treegrid's column
 * boundaries, and any Table that wants resizable columns too. Same three-way split every behaviour
 * here already uses (`hotkey.ts`'s own banner comment): the pure matcher here, the imperative
 * binding in `@skryensya/vanilla`, the declarative hook in `@skryensya/react`.
 *
 * WAI's pattern: `role="separator"`, `aria-orientation`, Left/Right move it, Shift+Left/Right moves
 * it FARTHER per keystroke, Home/End jump to the ends of its travel, Enter (and convention, though
 * not the spec: double-click) resets it. To WHAT is the consumer's own choice, same as "moving it"
 * below: Sidebar and Treegrid both reset to an even/default split, a resizable Table instead fits
 * the column to its own content (`@skryensya/vanilla/splitter`'s `measureColumnContentWidth`, the
 * spreadsheet convention), because "the neighbor happens to be the same width" and "this column can
 * show what's in it" are different questions, and only the second one is what a reader actually
 * expects from double-clicking a data column's edge. What "moving it" MEANS is the consumer's own
 * value model, never this file's: Sidebar redistributes one pane against a fixed bound via a CSS
 * `clamp()`; Treegrid and Table redistribute width between two ADJACENT columns whose sum stays
 * fixed. All are "a splitter", but the arithmetic differs (one clamps a single value, the other two
 * keep a pair summing to a constant). This file stays ignorant of which, and only ever hands back a
 * `delta` (or a `home`/`end`/`reset` intent) for the caller to apply however its own value model
 * requires.
 */

/** The one splitter every consumer starts from unless it has a reason not to. Sidebar and Treegrid
 * both do, today. */
export const SPLITTER_DEFAULTS = {
  /** How far, in px, a press must travel before it counts as a drag rather than a click. */
  dragThreshold: 4,
  /** One ArrowLeft/ArrowRight press, in the caller's own delta unit (px, almost always). */
  step: 16,
  /** One Shift+Arrow press. */
  coarseStep: 64,
} as const;

export interface SplitterKeyChord {
  readonly key: string;
  readonly shiftKey?: boolean;
}

/**
 * Which way the BAR runs, the same value the consumer writes on `aria-orientation`, and WAI's own
 * naming rather than the panes': a `vertical` separator is the upright bar between two panes sitting
 * side by side, a `horizontal` one is the rule between a pane above and a pane below.
 *
 * It decides which arrow keys mean anything. The APG is explicit that the off-axis pair does
 * nothing at all (Up/Down against a vertical splitter, Left/Right against a horizontal one), which
 * is why they resolve to `"none"` here rather than to a delta nobody asked for.
 */
export type SplitterOrientation = "vertical" | "horizontal";

export type SplitterKeyAction =
  | { readonly kind: "delta"; readonly delta: number }
  | { readonly kind: "home" }
  | { readonly kind: "end" }
  | { readonly kind: "reset" }
  | { readonly kind: "none" };

/**
 * One keystroke against a splitter, resolved against the caller's own step/coarseStep. Sidebar and
 * Treegrid both currently agree on 16/64, but neither is forced to via {@link SPLITTER_DEFAULTS}.
 * `"home"`/`"end"` mean "the minimum/maximum of this splitter's travel", not a literal direction -
 * resolving what that minimum or maximum IS (a measured bound, `+Infinity` for a clamp to saturate
 * against) is left to the caller, the same way `resolveTreegridKey` leaves "which row is home" to
 * its own.
 *
 * `orientation` decides which arrow pair is this splitter's (see {@link SplitterOrientation}); it
 * defaults to `vertical`, the upright bar every consumer here had when this file only knew one
 * axis. A delta stays a SIGNED SCALAR either way, never a point: the caller already knows which
 * measurement it is moving, and a splitter that handed back `{ x, y }` would be asking every
 * consumer to unpack an axis it chose itself.
 */
export function resolveSplitterKey(
  event: SplitterKeyChord,
  options: {
    readonly step?: number;
    readonly coarseStep?: number;
    readonly orientation?: SplitterOrientation;
  } = {},
): SplitterKeyAction {
  const step = options.step ?? SPLITTER_DEFAULTS.step;
  const coarseStep = options.coarseStep ?? SPLITTER_DEFAULTS.coarseStep;
  const orientation = options.orientation ?? "vertical";
  const magnitude = event.shiftKey ? coarseStep : step;
  const decrease = orientation === "horizontal" ? "ArrowUp" : "ArrowLeft";
  const increase = orientation === "horizontal" ? "ArrowDown" : "ArrowRight";

  if (event.key === decrease) return { kind: "delta", delta: -magnitude };
  if (event.key === increase) return { kind: "delta", delta: magnitude };

  switch (event.key) {
    case "Home":
      return { kind: "home" };
    case "End":
      return { kind: "end" };
    case "Enter":
      return { kind: "reset" };
    default:
      return { kind: "none" };
  }
}

/**
 * Whether pointer travel has crossed the drag threshold. The one piece of the "a press ARMS the
 * gesture, only travel past the threshold STARTS it" state machine (Sidebar's own vanilla binding
 * documents the full reasoning) that is pure math, so neither binding restates the constant or the
 * comparison.
 */
export function hasCrossedDragThreshold(
  startX: number,
  currentX: number,
  threshold: number = SPLITTER_DEFAULTS.dragThreshold,
): boolean {
  return Math.abs(currentX - startX) >= threshold;
}

/**
 * A value's position between two bounds, as a 0–100 percentage. What a focusable `role="separator"`
 * reports as `aria-valuenow`: a splitter's position is only meaningful RELATIVE to how far it can
 * travel, and a screen reader hearing a raw pixel count learns nothing from it. Returns 100 for a
 * degenerate range (`max` not greater than `min`) rather than dividing by zero.
 */
export function splitterValuePercent(value: number, min: number, max: number): number {
  if (!(max > min)) return 100;
  const clamped = Math.min(Math.max(value, min), max);
  return Math.round(((clamped - min) / (max - min)) * 100);
}

/**
 * RTL-aware sign for a pointer delta. A drag toward the reader's START is a drag toward LARGER x in
 * LTR and SMALLER x in RTL. Every splitter that resizes "whatever sits on the near side of the
 * handle" needs this same flip, read per-gesture (never cached) since a document can change
 * direction under a long-lived component.
 */
export function splitterDirectionSign(direction: "ltr" | "rtl"): 1 | -1 {
  return direction === "rtl" ? -1 : 1;
}

/*
 * ------------------------------------------------------------------------------------------------
 * COLUMN RESIZE. The adjacent-pair value model a resizable TABLE (any table: Treegrid grew this
 * first, a plain Table shares it verbatim) needs, and the one thing the rest of this file
 * deliberately does not know. A handle at index `i` sits BETWEEN column `i` and column `i + 1`;
 * dragging or arrowing it redistributes width between exactly that pair, so the table's own total
 * width never moves and every OTHER column stays exactly where it was. The same reason a
 * spreadsheet's column drag never disturbs a column two over. This is DIFFERENT from Sidebar's own
 * resize, which clamps ONE value against a fixed bound via a CSS `clamp()`: there is no "other pane"
 * to conserve total width with, so Sidebar never needed this half of the file at all.
 * ------------------------------------------------------------------------------------------------
 */

/** No CSS hook for this yet, unlike Sidebar's min/max (that contract's own note explains why those
 * ARE hooks): resizable columns are new, and a floor most columns never approach is a smaller
 * decision than the two bounds a resizable PANEL negotiates. Shared here so no binding restates the
 * number, the same reason {@link SPLITTER_DEFAULTS} lives here too. */
export const SPLITTER_MIN_COLUMN_WIDTH = 60;

/**
 * Redistributes width between column `index` and `index + 1` by `delta` px, clamped so NEITHER
 * column can shrink below `min`. The pair's combined width is invariant, so growing one is exactly
 * shrinking the other. `delta` of `+Infinity`/`-Infinity` (what a splitter's Home/End resolve to)
 * clamps straight to the max/min extent in one step, with no special-casing needed here:
 * `Math.min`/`Math.max` already saturate correctly against infinite input.
 */
export function resolveColumnResize(params: {
  readonly widths: readonly number[];
  readonly index: number;
  readonly delta: number;
  readonly min: number;
}): readonly number[] {
  const { widths, index, delta, min } = params;
  const before = widths[index];
  const after = widths[index + 1];
  if (before === undefined || after === undefined) return widths;
  const total = before + after;
  const nextBefore = Math.min(Math.max(before + delta, min), total - min);
  const result = widths.slice();
  result[index] = nextBefore;
  result[index + 1] = total - nextBefore;
  return result;
}

/*
 * ------------------------------------------------------------------------------------------------
 * COLUMN WEIGHTS. The INITIAL split of a resizable table's width across its columns, distinct from
 * `resolveColumnResize` above (which only ever touches one adjacent pair, after the fact). An equal
 * `total / colCount` split treats a content-heavy column. Treegrid's own hierarchy column, carrying
 * per-level indentation, a disclosure button, AND the row's label. Exactly like a flat metadata
 * column next to it, so the heavy column gets squeezed just as hard and truncates first. This is
 * ONLY ever a seed: once mounted, every later drag stays on `resolveColumnResize`'s own adjacent-pair
 * arithmetic, which does not need to know about weights at all.
 * ------------------------------------------------------------------------------------------------
 */

/**
 * Per-column width weights, encoded as one comma-separated attribute value (`columnWeights`'s own
 * `data-column-weights`) since the option system's `type` union has no array member. See
 * `contract.ts`. Returns `null` on anything that cannot become exactly `count` positive weights (a
 * missing attribute, a bad number, the wrong count), the two bindings' own cue to fall back to their
 * own default rather than seed from a half-parsed, possibly wrong-length array.
 */
export function parseColumnWeights(raw: string | null | undefined, count: number): readonly number[] | null {
  if (!raw) return null;
  const weights = raw.split(",").map((part) => Number.parseFloat(part.trim()));
  if (weights.length !== count) return null;
  if (weights.some((weight) => !Number.isFinite(weight) || weight <= 0)) return null;
  return weights;
}

/**
 * Splits `total` px across `weights.length` columns proportionally to `weights`, every column
 * floored at `min` first: `extra` (whatever is left once every column's floor is paid) is the only
 * part handed out by weight, so a heavily-weighted column can never starve a lighter neighbor below
 * the same floor `resolveColumnResize` itself enforces on every later drag. Equal weights reduce to
 * the exact `total / count` split every consumer used before this existed: `min + (total. Min *
 * count) / count` simplifies to `total / count` for any `count`.
 */
export function resolveWeightedColumnWidths(params: {
  readonly total: number;
  readonly weights: readonly number[];
  readonly min: number;
}): readonly number[] {
  const { total, weights, min } = params;
  if (weights.length === 0) return [];
  const extra = Math.max(0, total - min * weights.length);
  const weightSum = weights.reduce((sum, weight) => sum + weight, 0) || weights.length;
  return weights.map((weight) => min + (extra * weight) / weightSum);
}
