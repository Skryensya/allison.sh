import type { ComponentContract } from "./contract.js";

export type CheckedState = boolean | "indeterminate";

export type CheckedChangeDetails = {
  checked: CheckedState;
};

export type RadioValueChangeDetails = {
  value: string | null;
};

/**
 * What a CheckboxGroup reports: which children are checked, and the state that leaves the parent in.
 *
 * Both, and not just the values, because `checked` is the part a consumer cannot cheaply recompute
 * without also knowing how many children there are, which is the group's business, not the
 * listener's.
 */
export type CheckboxGroupValueChangeDetails = {
  value: readonly string[];
  checked: CheckedState;
};

export const checkboxGroupEvents = {
  valueChange: "sk:checkboxgroupvaluechange",
} as const;

export type RadioGroupOrientation = "horizontal" | "vertical";

export const selectionParts = {
  checkbox: "sk-checkbox",
  checkboxInput: "sk-checkbox__input",
  checkboxControl: "sk-checkbox__control",
  checkboxIndicator: "sk-checkbox__indicator",
  checkboxLabel: "sk-checkbox__label",
  radioGroup: "sk-radio-group",
  radio: "sk-radio",
  radioInput: "sk-radio__input",
  radioControl: "sk-radio__control",
  radioIndicator: "sk-radio__indicator",
  radioLabel: "sk-radio__label",
  switch: "sk-switch",
  switchInput: "sk-switch__input",
  switchControl: "sk-switch__control",
  switchThumb: "sk-switch__thumb",
  switchLabel: "sk-switch__label",
} as const;

export type SelectionPart = keyof typeof selectionParts;
export type SelectionPartClass = (typeof selectionParts)[SelectionPart];

/**
 * The checkbox family's parts: everything the three controls share, plus the two boxes only the
 * GROUP has.
 *
 * They are here and not in `selectionParts` because that map is the `parts` of all three contracts
 * at once, and a contract's parts are part of its published surface: adding a checkbox-group class
 * to the shared map moved the surface hash of Switch and RadioGroup, which had gained nothing and
 * had no entry to write about it. A family that grows a part should be the only family that
 * changes.
 */
export const checkboxParts = {
  ...selectionParts,
  checkboxGroup: "sk-checkbox-group",
  checkboxGroupItems: "sk-checkbox-group__items",
} as const;

/*
 * The two native selection controls, and the one place the system owns MORE structure than the
 * author does.
 *
 * A checkbox is five elements for one boolean: a `<label>` wrapping a real `<input>`, a painted
 * control beside it, two indicator spans inside that, and the text. The author supplies one thing,
 * the label, and the contract supplies the rest, because none of it is a choice: the native input
 * has to be there for form participation and keyboard, and the paint has to be `aria-hidden` so the
 * control is announced once, not twice.
 *
 * The label needs no `for` and the input needs no `id`: wrapping IS the association. That is the
 * platform's own rule, and it is why this contract has no wiring while FormField is made of it.
 */
export const checkboxContract = {
  id: "checkbox",
  category: "forms",
  css: "@skryensya/core/components/checkbox.css",
  /* Its own parts and hooks. It used to publish the shared `selectionParts` (radio and switch
     classes included) and sixteen `--sk-radio-*` hooks through radio-group.css and switch.css,
     while checkbox.css's own `--sk-checkbox-*` went unlisted. */
  parts: {
    checkbox: selectionParts.checkbox,
    checkboxInput: selectionParts.checkboxInput,
    checkboxControl: selectionParts.checkboxControl,
    checkboxIndicator: selectionParts.checkboxIndicator,
    checkboxLabel: selectionParts.checkboxLabel,
    checkboxGroup: checkboxParts.checkboxGroup,
    checkboxGroupItems: checkboxParts.checkboxGroupItems,
  },
  hooks: [
    "--sk-checkbox-bg",
    "--sk-checkbox-border-color",
    "--sk-checkbox-border-width",
    "--sk-checkbox-control-size",
    "--sk-checkbox-disabled-bg",
    "--sk-checkbox-disabled-border-color",
    "--sk-checkbox-disabled-fg",
    "--sk-checkbox-fg",
    "--sk-checkbox-gap",
    "--sk-checkbox-group-gap",
    "--sk-checkbox-group-indent",
    "--sk-checkbox-label-fg",
    "--sk-checkbox-radius",
    "--sk-checkbox-selected-bg",
    "--sk-checkbox-selected-border-color",
    "--sk-checkbox-selected-fg",
  ],

  options: {
    /*
     * HOW THE BOX IS DRAWN, Button's axis: `tactile` a raised box that sinks when pressed,
     * `brutalist` a black edge and hard offset, `frosted` a see-through box (opaque wherever the
     * material cannot be trusted). On the LABEL for a Checkbox and on the root for a group, the
     * elements that paint: the host of a Checkbox is its input.
     */
    appearance: {
      type: "enum",
      values: ["plain", "tactile", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
    name: { type: "string", attr: "name" },
    value: { type: "string", attr: "value" },
    /*
     * Where it STARTS. React spells it `defaultChecked`; a separate `checked` option used to map to
     * React's controlled `checked`, which a tree has no handler for: a box checked from a tree could
     * not be unchecked.
     */
    defaultChecked: {
      type: "boolean",
      default: false,
      attr: "checked",
      prop: "defaultChecked",
      trueValue: "",
    },
    defaultIndeterminate: {
      type: "boolean",
      default: false,
      attr: "data-default-indeterminate",
      prop: "defaultIndeterminate",
      trueValue: "",
    },
    disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
    required: { type: "boolean", default: false, attr: "required", trueValue: "" },
    orientation: {
      type: "enum",
      values: ["vertical", "horizontal"],
      default: "vertical",
      attr: "data-orientation",
    },
  },

  signatures: {
    Checkbox: {
      intent: ["boolean-choice", "opt-in", "accept-terms", "toggle-one-setting"],
      host: { element: "input" },
      options: ["name", "value", "defaultChecked", "defaultIndeterminate", "disabled", "required", "appearance"],
      /** Native form association beyond owned options (`name`/`value`/`disabled`/`required`). */
      forward: ["id", "form", "aria-*"],
      slots: {
        /** The visible text. Absent means the control is named by something else nearby. */
        children: { accepts: "node" },
      },
      template: {
        element: "label",
        part: "checkbox",
        options: ["appearance"],
        children: [
          {
            element: "input",
            part: "checkboxInput",
            host: true,
            attrs: { type: "checkbox" },
          },
          /*
           * The paint. `aria-hidden` is load-bearing: the native input above is what a screen reader
           * announces, and a second visible control would announce the same choice twice.
           */
          {
            element: "span",
            part: "checkboxControl",
            also: ["sk-interactive"],
            attrs: { "aria-hidden": "true" },
            children: [
              {
                element: "span",
                part: "checkboxIndicator",
                attrs: { "data-state": "checked" },
                children: [{ element: "span", attrs: { "data-sk-icon": "check", "data-sk-icon-size": "sm" } }],
              },
              {
                element: "span",
                part: "checkboxIndicator",
                attrs: { "data-state": "indeterminate" },
                children: [{ element: "span", attrs: { "data-sk-icon": "remove", "data-sk-icon-size": "sm" } }],
              },
            ],
          },
          { element: "span", part: "checkboxLabel", whenGiven: "children", slot: "children" },
        ],
      },
      react: { from: "@skryensya/react/selection", name: "Checkbox" },
    },

    /*
     * Many checkboxes and one that speaks for them, and the only signature here whose state is
     * DERIVED rather than authored.
     *
     * The parent is not a fourth option: it holds no `name` and no `value`, submits nothing, and
     * cannot be set to a value of its own. What it shows is a reading of its children. All, none,
     * or some, and what a click on it means is "make every child agree with me". That is why
     * `defaultIndeterminate` is absent from its options while Checkbox has it: on a lone checkbox
     * indeterminate is a state an author can assert, and here asserting it would be asserting
     * something the children may be about to contradict.
     *
     * Which children start checked is per-child data (`defaultChecked` on the entry), NOT a group
     * `value` the way RadioGroup has one. Exclusivity is what makes a radio group's selection the
     * group's; a checkbox group has no such claim, so the fact stays with the entry it is about.
     *
     * `role="group"` and not `radiogroup`: nothing here is exclusive, and the group is named by the
     * parent's own label, which is the one piece of text that already describes the whole set.
     */
    CheckboxGroup: {
      intent: ["select-all", "check-many-at-once", "partial-selection", "parent-checkbox"],
      host: { element: "div" },
      options: ["name", "orientation", "disabled", "required", "appearance"],
      requires: ["name"],
      mount: "data-sk-checkbox-group",
      /** Host id / form / a11y; name stays the option. */
      forward: ["id", "form", "aria-*"],
      slots: {
        /** The parent's text, and the group's accessible name via `labelledBySlot` below. */
        label: { accepts: "node", required: true },
        items: {
          accepts: "items",
          required: true,
          item: {
            key: "value",
            options: {
              value: { type: "string", attr: "value" },
              defaultChecked: { type: "boolean", default: false, attr: "checked", trueValue: "" },
              disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
            },
            slots: { label: { accepts: "node", required: true } },
          },
        },
      },
      template: {
        element: "div",
        part: "checkboxGroup",
        host: true,
        attrs: { role: "group" },
        labelledBySlot: "label",
        children: [
          {
            element: "label",
            part: "checkbox",
            children: [
              /*
               * No `name`, no `value`, and that absence is the contract: a form that submits this
               * group gets the children's values and nothing standing for "all of them", which
               * would be a fourth value the server never asked for.
               */
              {
                element: "input",
                part: "checkboxInput",
                mount: "data-sk-checkbox-group-all",
                attrs: { type: "checkbox" },
                options: ["disabled"],
              },
              {
                element: "span",
                part: "checkboxControl",
                also: ["sk-interactive"],
                attrs: { "aria-hidden": "true" },
                children: [
                  {
                    element: "span",
                    part: "checkboxIndicator",
                    attrs: { "data-state": "checked" },
                    children: [{ element: "span", attrs: { "data-sk-icon": "check", "data-sk-icon-size": "sm" } }],
                  },
                  {
                    element: "span",
                    part: "checkboxIndicator",
                    attrs: { "data-state": "indeterminate" },
                    children: [{ element: "span", attrs: { "data-sk-icon": "remove", "data-sk-icon-size": "sm" } }],
                  },
                ],
              },
              { element: "span", part: "checkboxLabel", slot: "label" },
            ],
          },
          {
            element: "div",
            part: "checkboxGroupItems",
            children: [
              {
                element: "label",
                part: "checkbox",
                repeat: "items",
                children: [
                  {
                    element: "input",
                    part: "checkboxInput",
                    mount: "data-sk-checkbox-group-item",
                    attrs: { type: "checkbox" },
                    options: ["name", "required"],
                    itemOptions: ["value", "defaultChecked", "disabled"],
                  },
                  {
                    element: "span",
                    part: "checkboxControl",
                    also: ["sk-interactive"],
                    attrs: { "aria-hidden": "true" },
                    children: [
                      {
                        element: "span",
                        part: "checkboxIndicator",
                        attrs: { "data-state": "checked" },
                        children: [{ element: "span", attrs: { "data-sk-icon": "check", "data-sk-icon-size": "sm" } }],
                      },
                      {
                        element: "span",
                        part: "checkboxIndicator",
                        attrs: { "data-state": "indeterminate" },
                        children: [{ element: "span", attrs: { "data-sk-icon": "remove", "data-sk-icon-size": "sm" } }],
                      },
                    ],
                  },
                  { element: "span", part: "checkboxLabel", itemSlot: "label" },
                ],
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/selection", name: "CheckboxGroup" },
    },
  },

  events: checkboxGroupEvents,
  eventDetails: {
    valueChange: { detail: { checked: "boolean | \"indeterminate\"", value: "string[]" }, reactProp: "onValueChange", source: "checkboxGroup", trigger: "checkboxInput" },
  },
} as const satisfies ComponentContract;

/*
 * A switch is its own family, not a checkbox variant: it means "this takes effect now" where a
 * checkbox means "this will be submitted", and it has its own stylesheet. They share a source module
 * and nothing else.
 */
export const switchContract = {
  id: "switch",
  category: "forms",
  css: "@skryensya/core/components/switch.css",
  /* Its own parts and its own hooks. It used to publish the shared `selectionParts` and sixteen
     RADIO hooks through checkbox.css and radio-group.css, while switch.css's own `--sk-switch-*`
     went unlisted: every override a consumer could actually use was undocumented. */
  parts: {
    switch: selectionParts.switch,
    switchInput: selectionParts.switchInput,
    switchControl: selectionParts.switchControl,
    switchThumb: selectionParts.switchThumb,
    switchLabel: selectionParts.switchLabel,
  },
  hooks: [
    "--sk-switch-bg",
    "--sk-switch-block-size",
    "--sk-switch-border-color",
    "--sk-switch-border-width",
    "--sk-switch-disabled-bg",
    "--sk-switch-disabled-border-color",
    "--sk-switch-disabled-fg",
    "--sk-switch-disabled-thumb-bg",
    "--sk-switch-fg",
    "--sk-switch-gap",
    "--sk-switch-inline-size",
    "--sk-switch-padding",
    "--sk-switch-selected-bg",
    "--sk-switch-selected-border-color",
    "--sk-switch-selected-thumb-bg",
    "--sk-switch-thumb-bg",
  ],

  options: {
    name: { type: "string", attr: "name" },
    value: { type: "string", attr: "value" },
    /*
     * Where it STARTS. React spells it `defaultChecked`: its `checked` is controlled, and a tree has
     * no handler to feed it, so an emitted `<Switch checked>` was a switch nobody could turn off.
     */
    defaultChecked: { type: "boolean", default: false, attr: "checked", trueValue: "", prop: "defaultChecked" },
    disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
    /*
     * HOW THE SWITCH IS DRAWN, Button's axis: `tactile` a raised thumb in a sunken well that sinks
     * when pressed, `brutalist` black edges and a hard-offset thumb, `frosted` a see-through track
     * (opaque wherever the material cannot be trusted). On the LABEL, the element that paints: the
     * host is the input.
     */
    appearance: {
      type: "enum",
      values: ["plain", "tactile", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
  },

  a11y: [
    {
      when: {},
      requiresOneOf: ["children", "aria-label", "aria-labelledby"],
      because: "A switch is a form control; with no visible label beside it, it needs an accessible name.",
      signatures: ["Switch"],
    },
  ],

  signatures: {
    Switch: {
      intent: ["on-off", "immediate-setting", "enable-feature"],
      host: { element: "input" },
      options: ["name", "value", "defaultChecked", "disabled", "appearance"],
      /** Native form association beyond owned options (`name`/`value`/`disabled`). */
      forward: ["id", "form", "aria-*"],
      slots: { children: { accepts: "node" } },
      template: {
        element: "label",
        part: "switch",
        options: ["appearance"],
        children: [
          { element: "input", part: "switchInput", host: true, attrs: { type: "checkbox", role: "switch" } },
          {
            element: "span",
            part: "switchControl",
            attrs: { "aria-hidden": "true" },
            children: [{ element: "span", part: "switchThumb" }],
          },
          { element: "span", part: "switchLabel", whenGiven: "children", slot: "children" },
        ],
      },
      react: { from: "@skryensya/react/selection", name: "Switch" },
    },
  },
} as const satisfies ComponentContract;

/*
 * One choice from a set, and the only selection family that is a collection.
 *
 * A radio is not a checkbox that happens to be exclusive: what makes it exclusive is the shared
 * `name` on every input, which is the platform's own mechanism and belongs to the GROUP, not to any
 * one option. Composing radios as loose children would leave that name to the author to repeat
 * correctly on each one, the same class of invariant a tab's key is, and the same answer: entries.
 *
 * `required` is likewise the group's: a set where one option is required means the SET is required.
 *
 * No custom DOM event and no enhancer: the browser's native `change` on each input is the whole
 * interaction. CheckboxGroup needs a custom event because the parent/child coordination is ours;
 * here exclusivity is the platform's.
 */
export const radioGroupContract = {
  id: "radio-group",
  category: "forms",
  css: "@skryensya/core/components/radio-group.css",
  /* Own parts and own hooks only. It used to publish the shared `selectionParts` plus checkbox
     group / switch sheets: every override a radio consumer could use lived next to classes and
     hooks that never painted this surface. */
  parts: {
    radioGroup: selectionParts.radioGroup,
    radio: selectionParts.radio,
    radioInput: selectionParts.radioInput,
    radioControl: selectionParts.radioControl,
    radioIndicator: selectionParts.radioIndicator,
    radioLabel: selectionParts.radioLabel,
  },
  hooks: [
    "--sk-radio-bg",
    "--sk-radio-border-color",
    "--sk-radio-border-width",
    "--sk-radio-control-size",
    "--sk-radio-disabled-bg",
    "--sk-radio-disabled-border-color",
    "--sk-radio-disabled-fg",
    "--sk-radio-fg",
    "--sk-radio-gap",
    "--sk-radio-group-gap",
    "--sk-radio-hit-size",
    "--sk-radio-selected-bg",
    "--sk-radio-selected-border-color",
    "--sk-radio-selected-fg",
  ],

  options: {
    /*
     * HOW THE RING IS DRAWN, Button's axis: `tactile` a raised disc that sinks when pressed,
     * `brutalist` a black edge and hard offset, `frosted` a see-through disc (opaque wherever the
     * material cannot be trusted). On the LABEL for a Radio and on the root for a group.
     */
    appearance: {
      type: "enum",
      values: ["plain", "tactile", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
    /** Shared by every input, and what makes the choice exclusive. The group's, never an option's. */
    name: { type: "string", attr: "name" },
    /**
     * The selected option, named by its key. A GROUP property: exclusivity is the claim that only
     * one can be selected, so no entry can own it.
     *
     * React spells it `defaultValue`, and the difference is not cosmetic: `value` there is the
     * CONTROLLED prop, so emitting it would freeze the demo on whichever option it named. The
     * markup's `data-value` is a starting point the machine then owns, which is what
     * `defaultValue` means. Same reasoning, same fix as Slider, Tabs and TimeField.
     */
    value: { type: "string", attr: "data-value", machineInput: true, prop: "defaultValue", keyOf: { slot: "items" } },
    /**
     * Two attributes, one value: the CSS reads `data-orientation` and the accessibility tree reads
     * `aria-orientation`, and a radiogroup owes the second one: arrow keys move along the axis it
     * announces. The template writes both from this single option.
     */
    /*
     * Every option the same width, across the whole group. A horizontal radio group sizes itself to
     * its options, which is right for two or three words side by side and wrong for a SCALE: a Likert
     * is read as equal steps, so the points have to be equally spaced whatever their labels weigh.
     * Layout only; the group is still a group and the browser still owns the choice.
     */
    spread: { type: "boolean", default: false, attr: "data-spread", trueValue: "" },
    /** A lone Radio's initial state. The group picks with `value`; one radio has no group to ask. */
    radioDefaultChecked: { type: "boolean", default: false, attr: "checked", trueValue: "", prop: "defaultChecked" },
    orientation: {
      type: "enum",
      values: ["vertical", "horizontal"],
      default: "vertical",
      attr: "data-orientation",
      alsoAttr: "aria-orientation",
    },
    /*
     * Claimed on each input (not the host div): a `disabled` attribute on a radiogroup wrapper does
     * nothing to the radios inside. React already OR'd group+item onto every input; emit now matches.
     */
    disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
    required: { type: "boolean", default: false, attr: "required", trueValue: "" },
    /** The group's accessible name. WAI's Radio Group pattern expects one on `role="radiogroup"`. */
    label: { type: "string", attr: "aria-label" },
  },

  a11y: [
    {
      when: {},
      requiresOneOf: ["label", "aria-label", "aria-labelledby"],
      because: "A radiogroup needs an accessible name; with no visible group label, pass label or aria-labelledby.",
      signatures: ["RadioGroup"],
    },
  ],

  signatures: {
    /*
     * ONE RADIO, ON ITS OWN. `RadioGroup` is the answer for a list of options and stays the default;
     * this is the case it cannot serve: a MATRIX, where every row is a question and every column a
     * point, so each cell holds a single radio. Radios sharing a `name` are one group to the browser
     * wherever they sit in the DOM, which is what makes a table of them work at all. The visible label
     * is optional here because in a matrix the row and column headers already name the cell; give it
     * `aria-label` (or `aria-labelledby`) when nothing else does.
     */
    Radio: {
      intent: ["one-radio", "matrix-cell", "radio-in-a-table", "grid-of-choices"],
      host: { element: "input" },
      options: ["name", "value", "radioDefaultChecked", "disabled", "required", "appearance"],
      requires: ["name"],
      /** Native form association and the naming a matrix needs, beyond the owned options. */
      forward: ["id", "form", "aria-*"],
      slots: {
        /** The visible text. Absent means the control is named by something else nearby. */
        children: { accepts: "node" },
      },
      template: {
        element: "label",
        part: "radio",
        options: ["appearance"],
        children: [
          { element: "input", part: "radioInput", host: true, attrs: { type: "radio" } },
          {
            element: "span",
            part: "radioControl",
            attrs: { "aria-hidden": "true" },
            children: [{ element: "span", part: "radioIndicator" }],
          },
          { element: "span", part: "radioLabel", whenGiven: "children", slot: "children" },
        ],
      },
      react: { from: "@skryensya/react/selection", name: "Radio" },
    },

    RadioGroup: {
      intent: ["one-of-many", "exclusive-choice", "pick-a-single-option"],
      host: { element: "div" },
      options: ["name", "value", "orientation", "spread", "disabled", "required", "label", "appearance"],
      requires: ["name"],
      /** Host id / a11y names beyond owned `label` / `name` options. */
      forward: ["id", "aria-*"],
      slots: {
        items: {
          accepts: "items",
          required: true,
          item: {
            key: "value",
            options: {
              value: { type: "string", attr: "value" },
              disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
            },
            slots: { label: { accepts: "node", required: true } },
          },
        },
      },
      template: {
        element: "div",
        part: "radioGroup",
        host: true,
        // The role is the contract's, not the author's: a div full of radios is not a radiogroup
        // until it says so, and every binding owes the same announcement.
        attrs: { role: "radiogroup" },
        children: [
          {
            element: "label",
            part: "radio",
            repeat: "items",
            children: [
              {
                element: "input",
                part: "radioInput",
                attrs: { type: "radio" },
                // `disabled` is claimed here so the host never gets a no-op `disabled` on the div.
                options: ["name", "required", "disabled"],
                itemOptions: ["value", "disabled"],
                selectedBy: { option: "value", attr: "checked" },
              },
              {
                element: "span",
                part: "radioControl",
                attrs: { "aria-hidden": "true" },
                children: [{ element: "span", part: "radioIndicator" }],
              },
              { element: "span", part: "radioLabel", itemSlot: "label" },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/selection", name: "RadioGroup" },
    },
  },
} as const satisfies ComponentContract;
