import type { ComponentContract, ContractSlot } from "./contract.js";

export type SelectOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type SelectValueChangeDetails = {
  value: string[];
};

export type SelectOptions = {
  /** How much body the trigger has: `outline` (absent) or `ghost`. */
  variant?: (typeof selectContract.options.variant.values)[number];
  /** How the field is drawn: `plain`, `brutalist` or `frosted`. Absent means plain. */
  appearance?: (typeof selectContract.options.appearance.values)[number];
  id?: string;
  name?: string;
  disabled?: boolean;
  required?: boolean;
  value?: string | readonly string[];
  defaultValue?: string | readonly string[];
  placeholder?: string;
  options?: readonly SelectOption[];
  onValueChange?: (details: SelectValueChangeDetails) => void;
};

export const selectEvents = {
  valueChange: "sk:selectvaluechange",
} as const;

/*
 * HOW THE MACHINE PLACES THE LISTBOX when the browser cannot - the fallback for a browser with no CSS
 * anchor positioning. Shared, because the two bindings had written it separately and disagreed:
 * React passed `{ sameWidth: false }` and the Vanilla enhancer passed a five-key object including
 * `sameWidth: true`. Same machine, same contract, two different listboxes.
 *
 * NOT A CONTRACT OPTION, and that distinction is the reason this is a plain const beside
 * `selectEvents` rather than an entry in `selectContract.options`. An option is a value a consumer
 * AUTHORS and that lands on an attribute; positioning is neither. It is configuration one machine
 * takes, which is exactly what `selectEvents` already is, and ADR-0010 already put this class of
 * shared non-contract fact in Core.
 *
 * `sameWidth: false` RESOLVES THE DISAGREEMENT TOWARD THE STYLESHEET. `select.css` gives the content
 * `inline-size: max-content` with `min-inline-size: var(--reference-width)` - at least as wide as the
 * trigger, free to grow past it. `sameWidth: true` pins the width to the trigger exactly, which
 * contradicts the sheet the same component ships; `false` leaves the sheet in charge on both paths.
 *
 * WHAT NOTHING PROVES: the browser gates run Chromium only, Chromium has the anchor API, and on that
 * path the machine's placement is the dead fallback with its style stripped before it reaches the DOM.
 * So this makes the two bindings SAY the same thing. Whether what they now say is right is as untested
 * after this as it was before, in both bindings.
 */
export const selectPositioning = {
  placement: "bottom-start",
  sameWidth: false,
  gutter: 8,
  flip: true,
} as const;

/*
 * The mount attributes, named once instead of spelled out at each `mount:` in the template.
 * This is the shape 31 other contracts already use, and what lets the vanilla layer derive
 * its selectors (`selectorsFor`) rather than retyping every one of these as `[data-sk-...]`.
 * The VALUES are unchanged: this renames nothing a consumer authors or an emitter writes.
 */
export const selectAttrs = {
  root: "data-sk-select",
  hidden: "data-sk-select-hidden",
  control: "data-sk-select-control",
  label: "data-sk-select-label",
  trigger: "data-sk-select-trigger",
  value: "data-sk-select-value",
  indicator: "data-sk-select-indicator",
  positioner: "data-sk-select-positioner",
  content: "data-sk-select-content",
  item: "data-sk-select-item",
  itemText: "data-sk-select-item-text",
  itemIndicator: "data-sk-select-item-indicator",
} as const;

export const selectParts = {
  native: "sk-select-native",
  root: "sk-select",
  control: "sk-select__control",
  label: "sk-select__label",
  trigger: "sk-select__trigger",
  value: "sk-select__value",
  indicator: "sk-select__indicator",
  positioner: "sk-select__positioner",
  content: "sk-select__content",
  item: "sk-select__item",
  itemText: "sk-select__item-text",
  itemIndicator: "sk-select__item-indicator",
} as const;

export type SelectPart = keyof typeof selectParts;
export type SelectPartClass = (typeof selectParts)[SelectPart];

/**
 * One choice: value, disabled, a required label. The shape `Select`'s own enhanced signature uses
 * verbatim, `Select.native` reuses with only the `value` option's `attr` overridden (a real
 * `<option value>` DOM attribute, not `data-value`), and `Combobox` builds on by adding its own
 * `description` slot. The same "export once, spread where it diverges" precedent `menuItemShape`
 * (`menu.ts`) already set, rather than three components hand-writing the same fields three times.
 */
export const selectableItemShape: NonNullable<ContractSlot["item"]> = {
  key: "value",
  options: {
    value: { type: "string", attr: "data-value" },
    disabled: { type: "boolean", default: false, attr: "data-disabled", trueValue: "" },
  },
  slots: { label: { accepts: "text", required: true } },
};


/*
 * SELECT, the contract: two signatures for two genuinely different components.
 *
 * `Select.native` is a real `<select>`: the browser owns selection, keyboard, form submission and
 * accessibility, and the system contributes one class. `Select` is the enhanced one, which exists
 * only when you need a controlled collection, item markup, positioning or the `sk:selectvaluechange`
 * event. Appearance stopped being a reason to replace the native control.
 *
 * Writing this contract turned up a divergence the docs had been carrying quietly: React renders a
 * `control` wrapper around the label and trigger, and the hand-authored markup on the docs page has
 * none. The CSS has zero rules for `__control`, so it was tempting to call React wrong, but the
 * vanilla enhancer already looks for `[data-sk-select-control]` and spreads Zag's props onto it when
 * it exists. Both bindings support the fuller shape; only the authored markup was short. So the
 * template below is the fuller one, and the page's markup was the incomplete source of truth all
 * along, which is the entire argument for emitting it instead of typing it.
 */
export const selectContract = {
  id: "select",
  category: "forms",
  css: "@skryensya/core/components/select.css",
  parts: selectParts,
  events: selectEvents,
  eventDetails: {
    valueChange: { detail: { value: "string[]" }, reactProp: "onValueChange", source: "root", trigger: "item" },
  },
  hooks: [
    "--sk-anchored-align",
    "--sk-anchored-arrow-edge",
    "--sk-anchored-arrow-near",
    "--sk-anchored-justify",
    "--sk-anchored-offset",
    "--sk-anchored-position-area",
    "--sk-anchored-position-try",
    "--sk-anchored-size",
    "--sk-anchored-z",
    "--sk-select-bg",
    "--sk-select-border-color",
    "--sk-select-border-width",
    "--sk-select-content-bg",
    "--sk-select-content-border-color",
    "--sk-select-content-max-block-size",
    "--sk-select-content-padding",
    "--sk-select-content-shadow",
    "--sk-select-content-wash",
    "--sk-select-disabled-bg",
    "--sk-select-disabled-border-color",
    "--sk-select-disabled-fg",
    "--sk-select-fg",
    "--sk-select-font-size",
    "--sk-select-height",
    "--sk-select-item-disabled-fg",
    "--sk-select-item-fg",
    "--sk-select-item-padding",
    "--sk-select-item-radius",
    "--sk-select-padding-x",
    "--sk-select-radius",
    "--sk-select-shadow",
    "--sk-select-state-opacity",
    "--sk-select-wash",
  ],
  /*
   * The listbox is placed with `sk-anchor` / `sk-anchored` (`also`). Those classes have no unique
   * contract owner, so `sheetsForTree` cannot discover `anchored.css` from `also` alone. Anchored
   * hooks are listed above so the hook gate stays closed (same shape as Combobox/Menu).
   */
  hookSheets: ["@skryensya/core/patterns/anchored.css"],

  options: {
    /*
     * HOW THE FIELD IS DRAWN, Input's axis: brutalist a black edge and hard offset in place of the
     * soft well, frosted a see-through field (opaque wherever the material cannot be trusted).
     * Every state still outranks it. Absent means plain, as for Input. No tactile: a field is typed
     * into, not pressed.
     */
    /*
     * HOW MUCH BODY THE TRIGGER HAS. `outline` (absent) is the bordered, filled field every other
     * form control is; `ghost` drops the fill, the border and the well and keeps only the value and
     * the chevron, with the shared state layer for hover, press and focus: a select that sits in a
     * toolbar, a card header or a row of people without drawing a box around itself. Absent means
     * outline, so existing markup is unchanged. Every state (invalid, disabled) still outranks it.
     */
    variant: {
      type: "enum",
      values: ["outline", "ghost"],
      attr: "data-variant",
    },
    appearance: {
      type: "enum",
      values: ["plain", "brutalist", "frosted"],
      attr: "data-appearance",
    },
    /** Submitted under this name, and what makes the hidden native control worth rendering. */
    name: { type: "string", attr: "name" },
    /**
     * The selected value. React spells it `defaultValue`: `value` there is the CONTROLLED prop, and
     * emitting it freezes the control. Same line Slider, Tabs, RadioGroup, TimeField and Segmented
     * carry: Segmented's absence was measured as a demo nobody could click.
     *
     * On `Select.native` the attr is the real HTML `value` on `<select>` (and `selected` on the
     * matching `<option>` via `selectedBy` below). On `Select` it is `data-value` for the enhancer.
     */
    value: { type: "string", attr: "data-value", prop: "defaultValue", machineInput: true, keyOf: { slot: "items" } },
    /** Shown in the trigger while nothing is selected. Empty until the author names one. */
    placeholder: { type: "string", default: "", attr: "data-placeholder", machineInput: true },
    disabled: { type: "boolean", default: false, attr: "data-disabled", trueValue: "", machineInput: true },
    required: { type: "boolean", default: false, attr: "data-required", trueValue: "", machineInput: true },
  },

  signatures: {
    "Select.native": {
      intent: ["a-standard-choice", "one-of-a-known-list", "form-field"],
      host: { element: "select" },
      options: ["name", "value", "disabled", "required"],
      /*
       * `name` / `value` / `disabled` / `required` are options (with native attrs via optionAttrs).
       * Remaining platform attrs an author still needs on a bare `<select>`.
       */
      forward: ["id", "form", "autocomplete", "aria-*"],
      slots: {
        /** The choices. A native `<option>` each, no item markup, which is the tradeoff. */
        items: {
          accepts: "items",
          required: true,
          /* The contract keys it `items` like every other collection; React calls it `options`. */
          prop: "options",
          /* `selectableItemShape`, with both attrs overridden to real DOM attributes: a native
             `<option value disabled>` reads `value`/`disabled` directly, never `data-value`/
             `data-disabled`: the browser's own disabling only works on the real attribute. */
          item: {
            ...selectableItemShape,
            options: {
              value: { ...selectableItemShape.options.value, attr: "value" },
              disabled: { ...selectableItemShape.options.disabled, attr: "disabled" },
            },
          },
        },
      },
      template: {
        element: "select",
        part: "native",
        host: true,
        /*
         * Shared option attrs are the enhanced signature's `data-*` machine channel. A real
         * `<select>` needs the platform spellings; `value` is suppressed here because the matching
         * `<option selected>` (via `selectedBy`) is what static HTML actually uses.
         */
        optionAttrs: { disabled: "disabled", required: "required", value: "" },
        children: [
          {
            element: "option",
            repeat: "items",
            itemOptions: ["value", "disabled"],
            /* The option the browser shows as chosen, marked the way the platform marks it. */
            selectedBy: { attr: "selected", option: "value" },
            itemSlot: "label",
          },
        ],
      },
      react: { from: "@skryensya/react/select-native", name: "NativeSelect" },
    },

    Select: {
      intent: ["controlled-collection", "item-markup", "positioned-listbox", "value-change-event"],
      host: { element: "div" },
      mount: selectAttrs.root,
      options: ["name", "value", "placeholder", "disabled", "required", "variant", "appearance"],
      portals: { container: true },
      /** Host id / a11y names; form association stays on the hidden native input. */
      forward: ["id", "aria-*"],
      slots: {
        /** Names the control. Absent means something else nearby names it. */
        label: { accepts: "text" },
        items: { accepts: "items", required: true, prop: "options", item: selectableItemShape },
      },
      template: {
        element: "div",
        part: "root",
        host: true,
        children: [
          /*
           * The hidden native control, so the value reaches a form submission.
           *
           * This was left out at first, on the theory that form participation is the binding's job.
           * G2 disagreed and was right twice over: React renders one through Zag, so omitting it
           * made the two bindings produce different DOM, and the vanilla enhancer only ADOPTS an
           * authored hidden select, it never creates one, so markup without it silently submitted
           * nothing. `itemOptionAttrs` exists because of this node: the same entry value is
           * `data-value` on the listbox row and `value` here.
           */
          {
            element: "select",
            mount: selectAttrs.hidden,
            attrs: {
              "aria-hidden": "true",
              tabindex: "-1",
              /* Zag's own visually-hidden declaration, byte for byte: a second spelling of the same rule
               * reads as a divergence to G2 and is one more thing that can drift. */
              style:
                "border:0;clip:rect(0 0 0 0);height:1px;margin:-1px;overflow:hidden;padding:0;position:absolute;width:1px;white-space:nowrap;word-wrap:normal;",
            },
            options: ["name"],
            children: [
              {
                element: "option",
                repeat: "items",
                itemOptions: ["value", "disabled"],
                itemOptionAttrs: { value: "value", disabled: "disabled" },
                /* The option the browser submits, marked the way the platform marks it. */
                selectedBy: { attr: "selected", option: "value" },
                itemSlot: "label",
              },
            ],
          },
          {
            element: "div",
            part: "control",
            mount: selectAttrs.control,
            children: [
              {
                element: "label",
                part: "label",
                mount: selectAttrs.label,
                slot: "label",
                whenGiven: "label",
              },
              {
                element: "button",
                part: "trigger",
                also: ["sk-anchor", "sk-interactive"],
                mount: selectAttrs.trigger,
                attrs: { type: "button" },
                children: [
                  { element: "span", part: "value", mount: selectAttrs.value },
                  {
                    element: "span",
                    part: "indicator",
                    mount: selectAttrs.indicator,
                    attrs: { "aria-hidden": "true" },
                    children: [
                      {
                        element: "span",
                        attrs: { "data-state": "closed" },
                        children: [{ element: "span", attrs: { "data-sk-icon": "chevron-down", "data-sk-icon-size": "md" } }],
                      },
                      {
                        element: "span",
                        attrs: { "data-state": "open" },
                        children: [{ element: "span", attrs: { "data-sk-icon": "chevron-up", "data-sk-icon-size": "md" } }],
                      },
                    ],
                  },
                ],
              },
            ],
          },
          {
            element: "div",
            part: "positioner",
            also: ["sk-anchored"],
            mount: selectAttrs.positioner,
            children: [
              {
                element: "ul",
                part: "content",
                mount: selectAttrs.content,
                children: [
                  {
                    element: "li",
                    part: "item",
                    also: ["sk-interactive"],
                    mount: selectAttrs.item,
                    repeat: "items",
                    itemOptions: ["value", "disabled"],
                    children: [
                      {
                        element: "span",
                        part: "itemText",
                        mount: selectAttrs.itemText,
                        itemSlot: "label",
                      },
                      {
                        element: "span",
                        part: "itemIndicator",
                        mount: selectAttrs.itemIndicator,
                        children: [{ element: "span", attrs: { "data-sk-icon": "check", "data-sk-icon-size": "md" } }],
                      },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/select", name: "Select" },
    },
  },
} as const satisfies ComponentContract;
