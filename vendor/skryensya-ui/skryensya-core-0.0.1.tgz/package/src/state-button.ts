import type { ComponentContract } from "./contract.js";
import { stableIconNames, type StableIconName } from "./icon.js";
import { iconToggleAttrs, iconToggleParts } from "./icon-toggle.js";

/*
 * ICON STATE BUTTON, decision 33 reversed: this is the public signature now, not a primitive
 * underneath two others. An icon-only button whose faces are author-supplied. A `faces` items
 * slot, one `{ name, icon }` entry per state, because the set of states is different every time
 * it is used (idle/copied for a copy action, system/light/dark for a color mode) and a fixed enum
 * baked into one contract cannot say that.
 *
 * WHICH FACE IS CURRENT is `current`, a plain string option compared against each entry's own
 * `name`: the same pairing RadioGroup already does between its `value` option and each item's
 * `value` (`selection.ts`), reused here via `selectedBy` against Icon Toggle's own `data-active`
 * marker instead of a component-specific state attribute. Because `selectedBy` resolves at EMIT
 * TIME, the correct face already carries `data-active` in the first paint: no JS, no FOUC gap,
 * the same property CopyButton and ThemeToggle used to buy with their own hand-written CSS.
 *
 * WHAT THIS CONTRACT DOES NOT DO is decide when `current` changes, or what a click does at all: no
 * `mount`, no vanilla enhancer, no behavior. A button that shows one of N icons and does nothing on
 * click is not useful on its own; a consumer supplies the click handling, the timer, the clipboard
 * write, the cross-instance broadcast. Whatever the actual feature needs, and updates `current`
 * (or the DOM `data-active`) itself. `setIconState`/`getIconState` below are for exactly that: a
 * small, optional imperative helper, not part of the contract.
 */

export type IconStateFace = {
  readonly name: string;
  readonly icon: StableIconName;
};

export const stateButtonParts = {
  root: "sk-state-button",
} as const;

export type StateButtonPart = keyof typeof stateButtonParts;
export type StateButtonPartClass = (typeof stateButtonParts)[StateButtonPart];

export const stateButtonAttrs = {
  root: "data-sk-state-button",
  current: "data-current",
  face: "data-face",
} as const;

export type StateButtonAttr = keyof typeof stateButtonAttrs;
export type StateButtonAttrName = (typeof stateButtonAttrs)[StateButtonAttr];

/**
 * Imperative set/read of a state attribute plus, when given, the accessible name. For a
 * consumer's own behavior script to call after its own click/cycle logic decides the next state.
 * Not wired to `current` above automatically: this contract has no enhancer to do that wiring.
 */
export function setIconState(root: HTMLElement, attr: string, value: string | undefined, ariaLabel?: string): void {
  if (value === undefined) root.removeAttribute(attr);
  else root.setAttribute(attr, value);
  if (ariaLabel !== undefined) root.setAttribute("aria-label", ariaLabel);
}

export function getIconState(root: HTMLElement, attr: string): string | null {
  return root.getAttribute(attr);
}

export const stateButtonContract = {
  id: "state-button",
  category: "actions",
  css: "@skryensya/core/components/state-button.css",
  parts: stateButtonParts,
  hooks: [
    "--sk-state-button-rest-blur",
    "--sk-state-button-rest-scale",
    "--sk-state-button-transition-duration",
    "--sk-state-button-transition-easing",
  ],

  options: {
    /** Which face's `name` is current. Absent means no face carries `data-active` at all. */
    current: { type: "string", attr: stateButtonAttrs.current, keyOf: { slot: "faces" } },
  },

  signatures: {
    StateButton: {
      intent: ["icon-button-with-states", "multi-state-icon-button"],
      host: { element: "button" },
      options: ["current"],
      /*
       * Button look attrs (`data-variant` / `data-size` / `data-appearance`) stay on the host via
       * `also: sk-button`, not re-declared as options here: Button's own sheet paints every one of
       * them, appearance included. Form association and a11y names mirror Button.action.
       */
      forward: ["id", "name", "form", "data-variant", "data-size", "data-appearance", "aria-*"],
      slots: {
        /** One entry per state. `name` is what `current` is compared against; `icon` is the glyph. */
        faces: {
          accepts: "items",
          required: true,
          /* One face is not a state button; that is a Button, or a Switch for on and off. */
          minItems: 2,
          item: {
            key: "name",
            /* A face with no glyph shows nothing when it becomes current. */
            requires: ["icon"],
            options: {
              name: { type: "string", attr: stateButtonAttrs.face },
              icon: { type: "enum", values: stableIconNames, attr: "data-sk-icon" },
            },
            slots: {},
          },
        },
      },
      compose: [
        { of: "button", sheets: ["@skryensya/core/components/button.css"], systemOwned: true },
        { of: "icon", systemOwned: true },
      ],
      template: {
        element: "button",
        part: "root",
        host: true,
        also: ["sk-button", "sk-interactive", iconToggleParts.root],
        /*
         * Always icon-only: faces are glyphs, never a text label. Without `data-icon-only`,
         * `button.css` keeps the default padded control width and the square shape the pattern
         * documents never arrives. Variant/size stay Button's own attrs (ghost + sm is the common
         * toolbar shape); this contract does not re-declare them.
         */
        attrs: { type: "button", "data-icon-only": "" },
        children: [
          {
            repeat: "faces",
            children: [
              {
                /* No `part`: a face IS the icon placeholder, nothing wraps it, and `sk-icon`
                   itself (written once the real set replaces this span) is already the only
                   class that means anything here. A second one with no rule to match would be
                   the divergence G2 exists to catch, not real anatomy. `data-sk-icon-size` is the
                   one attribute that IS load-bearing: it is how the icon-mounting enhancer knows
                   what size to render, read once and never copied to the final `<svg>`
                   (`controlAttrs` in `vanilla/src/icon.ts`). React's own `<Icon>` needs no
                   equivalent since its `size` prop already defaults to `"md"`. */
                element: "span",
                attrs: { "data-sk-icon-size": "md" },
                itemOptions: ["name", "icon"],
                selectedBy: { option: "current", attr: iconToggleAttrs.active },
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/state-button", name: "StateButton" },
    },
  },

  a11y: [
    {
      when: {},
      requiresOneOf: ["aria-label", "aria-labelledby"],
      because:
        "StateButton is always icon-only: faces are glyphs with no visible text, so the host owns the accessible name.",
    },
  ],
} as const satisfies ComponentContract;
