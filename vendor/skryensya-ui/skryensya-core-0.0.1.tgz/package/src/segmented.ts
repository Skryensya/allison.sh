import type { ComponentContract } from "./contract.js";

/*
 * SEGMENTED CONTROL, a single choice from a small, fixed set, shown all at once.
 *
 * It is a radio group wearing a button-bar's clothes: exactly one option is selected, the options
 * are few and mutually exclusive, and the whole set is visible. For navigation between panels use
 * Tabs; for many options or free text use Select.
 */
export type SegmentedOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export const segmentedParts = {
  root: "sk-segmented",
  option: "sk-segmented__option",
  indicator: "sk-segmented__indicator",
} as const;

export type SegmentedPart = keyof typeof segmentedParts;
export type SegmentedPartClass = (typeof segmentedParts)[SegmentedPart];

/*
 * A small exclusive choice, shown as one bar. Radios by role (`radiogroup` of `radio`) rather than by
 * element, because the options are buttons, which is what gives them a shared indicator to slide.
 *
 * ONE tab stop: only the selected option is reachable, the arrows move between them. That roving
 * tabindex is why a Toolbar counts a Segmented as one stop and not N (decision 27).
 */
/** The DOM events this family dispatches on its root, `sk:<family><event>` like every other. */
export const segmentedEvents = {
  /** Detail: `{ value: string }`. */
  valueChange: "sk:segmentedvaluechange",
} as const;

export const segmentedContract = {
  id: "segmented",
  category: "forms",
  css: "@skryensya/core/components/segmented.css",
  parts: segmentedParts,
  events: segmentedEvents,
  eventDetails: {
    valueChange: { detail: { value: "string" }, reactProp: "onValueChange", reactDetail: "string", source: "root", trigger: "option" },
  },
  hooks: [
    "--sk-segmented-bg",
    "--sk-segmented-block-size",
    "--sk-segmented-border-color",
    "--sk-segmented-border-width",
    "--sk-segmented-brutalist-offset",
    "--sk-segmented-gap",
    "--sk-segmented-font-size",
    "--sk-segmented-option-fg",
    "--sk-segmented-option-padding-inline",
    "--sk-segmented-padding",
    "--sk-segmented-radius",
    "--sk-segmented-selected-bg",
    "--sk-segmented-selected-elevation",
    "--sk-segmented-selected-fg",
    "--sk-segmented-selected-ring",
    "--sk-segmented-selected-wash",
    "--sk-segmented-shadow",
    "--sk-segmented-wash",
  ],

  options: {
    /**
     * Which option is selected. A group property: exclusivity means only one can be.
     *
     * React spells it `defaultValue`. Emitting `value` there hands React its CONTROLLED prop with no
     * `onValueChange` beside it, which freezes the control: measured on /componentes/segmented,
     * clicking the second option moved the Vanilla stage and left React on the first. The markup's
     * `data-value` is a starting point the machine then owns: that is what `defaultValue` means.
     * Slider, Tabs, RadioGroup and TimeField all carry this line; Segmented never got it.
     */
    value: { type: "string", attr: "data-value", prop: "defaultValue", keyOf: { slot: "items" } },
    /** The group's own accessible name. WAI's Radio Group pattern expects one; this `role="radiogroup"`
     *  had no way to carry it at all before this option existed. Every real usage passed `aria-label`
     *  by hand, outside the contract. */
    label: { type: "string", attr: "aria-label" },
    /*
     * HOW THE CONTROL IS DRAWN, Button's axis: `tactile` a raised key in a deeper well, `brutalist` a
     * black-edged track with a hard offset, `frosted` a see-through track (opaque wherever the
     * material cannot be trusted). Hooks only: the indicator's own motion is untouched.
     */
    appearance: {
      type: "enum",
      values: ["plain", "tactile", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
    /*
     * The TRACK's size, on Button's scale: `sm` is the size it has always been, the height of a
     * small button it usually sits beside; `md` and `lg` are for a segmented control that is the
     * thing on screen rather than one more control in a row, like the value switcher of a
     * documentation preview. Height, type and the options' inline padding move together.
     */
    size: { type: "enum", values: ["sm", "md", "lg"], default: "sm", attr: "data-size" },
  },

  signatures: {
    Segmented: {
      intent: ["small-exclusive-choice", "view-switcher", "two-or-three-options"],
      host: { element: "div" },
      options: ["value", "label", "appearance", "size"],
      requires: ["value", "label"],
      /** Host id / a11y; label stays the option. */
      forward: ["id", "aria-*"],
      slots: {
        items: {
          accepts: "items",
          prop: "options",
          required: true,
          item: {
            key: "value",
            options: {
              value: { type: "string", attr: "data-value" },
              disabled: { type: "boolean", default: false, attr: "disabled", trueValue: "" },
            },
            slots: { label: { accepts: "text", required: true } },
          },
        },
      },
      template: {
        element: "div",
        part: "root",
        host: true,
        attrs: { role: "radiogroup" },
        children: [
          // The sliding highlight. Decorative: the selected option already announces itself.
          { element: "span", part: "indicator", attrs: { "aria-hidden": "true" } },
          {
            element: "button",
            part: "option",
            also: ["sk-interactive"],
            attrs: { type: "button", role: "radio" },
            // The enhancer scans for these, so each option carries its own mount mark.
            mount: "data-sk-segmented-option",
            repeat: "items",
            itemOptions: ["value", "disabled"],
            selectedBy: { option: "value", attr: "aria-checked" },
            itemSlot: "label",
          },
        ],
      },
      // The export is `SegmentedControl`; the signature is `Segmented` because that is the concept.
      // Naming them apart is the point of a signature id being separate from an export name.
      react: { from: "@skryensya/react/segmented", name: "SegmentedControl" },
      mount: "data-sk-segmented",
    },
  },
} as const satisfies ComponentContract;
