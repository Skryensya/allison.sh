import type { ComponentContract } from "./contract.js";
export type CodePreviewDensity = "condensed" | "full";

/**
 * Stable anatomy for a Shiki-rendered code preview.
 *
 * Core owns only the authored DOM contract. Highlighting stays at build/SSR time; the opt-in
 * Vanilla enhancer binds the density and disclosure controls without importing Shiki in the browser.
 */
export const codePreviewParts = {
  root: "sk-code-preview",
  label: "sk-code-preview__label",
  meta: "sk-code-preview__meta",
  density: "sk-code-preview__density",
  densityEdge: "sk-code-preview__density-edge",
  preview: "sk-code-preview__preview",
  viewport: "sk-code-preview__viewport",
  more: "sk-code-preview__more",
  toggle: "sk-code-preview__toggle",
  toggleCount: "sk-code-preview__toggle-count",
  toggleIcon: "sk-code-preview__toggle-icon",
} as const;

export type CodePreviewPart = keyof typeof codePreviewParts;
export type CodePreviewPartClass = (typeof codePreviewParts)[CodePreviewPart];

/** Data attributes consumed by the opt-in Vanilla enhancer. */
export const codePreviewAttrs = {
  root: "data-sk-code-preview",
  density: "data-sk-code-preview-density",
  densityInput: "data-sk-code-preview-density-input",
  densityPanel: "data-sk-code-preview-density-panel",
  collapsible: "data-sk-code-preview-collapsible",
  /** Present when the Condensed panel itself is long enough to disclose (not only Full). */
  condensedCollapsible: "data-sk-code-preview-condensed-collapsible",
  expanded: "data-sk-code-preview-expanded",
  lines: "data-sk-code-preview-lines",
  condensedLines: "data-sk-code-preview-condensed-lines",
  previewLines: "data-sk-code-preview-preview-lines",
  more: "data-sk-code-preview-more",
  toggle: "data-sk-code-preview-toggle",
  toggleLabel: "data-sk-code-preview-toggle-label",
  expandedLabel: "data-sk-code-preview-expanded-label",
  expandedAriaLabel: "data-sk-code-preview-expanded-aria-label",
  /**
   * How to say "{count} lines" in the page's language. The enhancer rewrites the count when the
   * density switch flips panels, and it cannot know the language: this carries the sentence with
   * `{count}` still in it, so the substitution stays the enhancer's job and the wording stays the
   * author's. Without it the count could only be hardcoded, which is how it ended up Spanish on
   * the English site.
   */
  linesLabel: "data-sk-code-preview-lines-label",
  /**
   * Present when a collapsed panel shows NOTHING (a consumer that forced collapsibility below the
   * sitewide peek-window threshold  -  see `ComponentPreview`'s own `forceCollapsible`), as opposed
   * to the default 15-line window, which stays genuinely visible and scrollable while collapsed.
   * The enhancer reads this to decide whether a panel's own viewport needs `inert` toggled in
   * step with `expanded`: a real peek window keeps its keyboard/AT reachability at rest; an empty
   * one must not offer a stop a reader can tab to and find nothing at.
   */
  hidesWhenCollapsed: "data-sk-code-preview-hides-when-collapsed",
} as const;

export type CodePreviewAttr = keyof typeof codePreviewAttrs;
export type CodePreviewAttrName = (typeof codePreviewAttrs)[CodePreviewAttr];

/*
 * CODE PREVIEW, the contract: a block of code with a window over it.
 *
 * The enhancer shipped with no React counterpart, so this could not be a contract: one binding is
 * not a contract, it is a script. Writing the missing half is what made it publishable, the same as
 * `dialog` and `command-palette`.
 *
 * HIGHLIGHTING IS NOT THIS COMPONENT'S JOB. Shiki runs at build or on the server and never in the
 * browser, so the code arrives already marked up and `children` is whatever the author produced.
 * What this owns is the chrome: the label row, the disclosure, and the LINE COUNTS that turn
 * "show 40 more lines" into a real number. Those counts are machine input in the strict sense:
 * they are measured where the code is highlighted and authored markup has no other channel for them.
 *
 * ONE SIGNATURE, NOT TWO, for now. The docs' own `CodeBlock` also renders a DENSITY variant: two
 * panels, condensed and full, with a switch between them. That is a second signature with its own
 * anatomy and its own required pair of slots, and it is deliberately not guessed at here.
 */
export const codePreviewContract = {
  id: "code-preview",
  category: "content",
  css: "@skryensya/core/components/code-preview.css",
  parts: codePreviewParts,
  hooks: [
    "--sk-code-preview-bg",
    "--sk-code-preview-border-color",
    "--sk-code-preview-brutalist-offset",
    "--sk-code-preview-collapsed-padding-block",
    "--sk-code-preview-copy-scroll-inset",
    "--sk-code-preview-copy-sticky-top",
    "--sk-code-preview-count-fg",
    "--sk-code-preview-fg",
    "--sk-code-preview-font-size",
    "--sk-code-preview-footer-bg",
    "--sk-code-preview-label-active-fg",
    "--sk-code-preview-label-bg",
    "--sk-code-preview-label-fg",
    "--sk-code-preview-window",
  ],
  /*
   * Density composes a real `sk-switch` (`also`). That class is claimed by checkbox/switch/radio
   * parts maps, so `sheetsForTree` cannot discover `switch.css` from `also` alone, name it here
   * (same shape as TileCheckbox/TileSwitch).
   */
  hookSheets: ["@skryensya/core/components/switch.css"],

  options: {
    /*
     * HOW THE PANEL IS DRAWN, Button's axis: brutalist a black edge, black dividers and a hard
     * offset, frosted a see-through panel (opaque wherever the material cannot be trusted). No
     * tactile: a code panel is never pressed.
     */
    appearance: {
      type: "enum",
      values: ["plain", "brutalist", "frosted"],
      default: "plain",
      attr: "data-appearance",
    },
    /** The panel is taller than its window, so it gets a disclosure control. */
    collapsible: { type: "boolean", default: false, attr: codePreviewAttrs.collapsible, trueValue: "", machineInput: true },
    /** Total lines, and how many the collapsed window shows. Counted where the code is made. */
    lines: { type: "number", attr: codePreviewAttrs.lines, machineInput: true },
    previewLines: { type: "number", attr: codePreviewAttrs.previewLines, machineInput: true },
    /**
     * What the disclosure says while collapsed, and once open.
     *
     * Expand/collapse, not "see all"/"see less": the collapsed window SCROLLS (see
     * components/code-preview.css), so every line is already reachable either way. What the control
     * changes is how much room the block takes on the page, and the words have to say that much and
     * no more, or they promise content that was never withheld.
     *
     * Collapsed copy is visible text (`textFromOption` on the toggle label), not a host data
     * attribute, same shape as Popover's `closeLabel`.
     */
    moreLabel: { type: "string", default: "Expand" },
    /** Expanded copy: the enhancer reads it off the toggle (`data-sk-code-preview-expanded-label`). */
    lessLabel: { type: "string", default: "Collapse", attr: codePreviewAttrs.expandedLabel, machineInput: true },
    /**
     * What the density switch announces. An option, not a slot: it lands on `aria-label`, and a
     * slot would need a way to copy its text onto an attribute of a node it does not render.
     * It says what the switch DOES, because the words at each end are out of a screen reader's reach.
     */
    switchLabel: { type: "string", default: "Show the full version", attr: "aria-label" },
  },

  signatures: {
    CodePreview: {
      intent: ["code-block", "show-a-snippet", "long-code-with-a-window"],
      host: { element: "div" },
      mount: codePreviewAttrs.root,
      options: ["collapsible", "lines", "previewLines", "moreLabel", "lessLabel", "appearance"],
      compose: [
        { of: "button", sheets: ["@skryensya/core/components/button.css"], systemOwned: true },
        { of: "icon", systemOwned: true },
      ],
      slots: {
        /** The code itself, already highlighted. */
        children: { accepts: "node", required: true },
        /** What this snippet is: a filename, a language, a step. */
        label: { accepts: "text" },
        /** A second line beside the label: a caveat, a version. */
        note: { accepts: "text" },
      },
      template: {
        element: "div",
        part: "root",
        host: true,
        children: [
          {
            element: "div",
            part: "label",
            whenGiven: ["label", "note"],
            children: [
              {
                element: "span",
                part: "meta",
                children: [
                  { element: "span", slot: "label", whenGiven: "label" },
                  { element: "span", slot: "note", whenGiven: "note" },
                ],
              },
            ],
          },
          {
            element: "div",
            part: "preview",
            /* `preserveWhitespace`: this box is `white-space: pre-wrap` (code-preview.css), so the
               printer's own indentation would be rendered as blank lines and leading spaces. */
            children: [
              { element: "div", part: "viewport", slot: "children", preserveWhitespace: true },
            ],
          },
          {
            element: "div",
            part: "more",
            mount: codePreviewAttrs.more,
            whenGiven: "collapsible",
            children: [
              {
                element: "button",
                part: "toggle",
                also: ["sk-button", "sk-interactive"],
                mount: codePreviewAttrs.toggle,
                options: ["lessLabel"],
                attrs: {
                  type: "button",
                  "aria-expanded": "false",
                  "data-size": "sm",
                  "data-variant": "ghost",
                },
                children: [
                  { element: "span", mount: codePreviewAttrs.toggleLabel, textFromOption: "moreLabel" },
                  /* Filled by the enhancer once there is a layout to measure. */
                  { element: "span", part: "toggleCount" },
                  {
                    element: "span",
                    part: "toggleIcon",
                    children: [
                      { element: "span", attrs: { "data-sk-icon": "chevron-down", "data-sk-icon-size": "sm" } },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/code-preview", name: "CodePreview" },
    },

    /*
     * THE DENSITY VARIANT: two panels and a switch between them.
     *
     * A second signature rather than an option on the first, because the anatomy genuinely differs:
     * one panel becomes two, each addressable, and a control appears that has no meaning without
     * them. `CodePreview` with a `density` flag would have carried two slots that are required when
     * the flag is set and forbidden when it is not, which is a signature wearing a disguise.
     *
     * The switch is a real `sk-switch`, not a pair of buttons: one binary choice with two named
     * ends. The ends are labels BESIDE it, not its accessible name: the name says what the switch
     * does, which is what a screen reader needs when the words beside it are out of reach.
     */
    "CodePreview.density": {
      intent: ["condensed-and-full-code", "two-levels-of-detail", "code-with-a-density-switch"],
      host: { element: "div" },
      mount: codePreviewAttrs.root,
      options: ["collapsible", "lines", "previewLines", "moreLabel", "lessLabel", "switchLabel", "appearance"],
      compose: [
        { of: "button", sheets: ["@skryensya/core/components/button.css"], systemOwned: true },
        { of: "icon", systemOwned: true },
        { of: "switch", sheets: ["@skryensya/core/components/switch.css"], systemOwned: true },
      ],
      slots: {
        /** The short version, shown first. */
        condensed: { accepts: "node", required: true },
        /** Everything, behind the switch. */
        full: { accepts: "node", required: true },
        label: { accepts: "text" },
        /** What each end of the switch is called, and what the switch itself announces. */
        condensedLabel: { accepts: "text", required: true },
        fullLabel: { accepts: "text", required: true },
      },
      template: {
        element: "div",
        part: "root",
        host: true,
        attrs: { "data-sk-code-preview-density": "condensed" },
        children: [
          {
            element: "div",
            part: "label",
            children: [
              {
                element: "span",
                part: "meta",
                children: [{ element: "span", slot: "label", whenGiven: "label" }],
              },
              {
                element: "div",
                part: "density",
                children: [
                  {
                    element: "span",
                    part: "densityEdge",
                    attrs: { "data-density": "condensed" },
                    slot: "condensedLabel",
                  },
                  {
                    element: "label",
                    also: ["sk-switch"],
                    children: [
                      {
                        element: "input",
                        also: ["sk-switch__input"],
                        mount: codePreviewAttrs.densityInput,
                        attrs: { type: "checkbox", role: "switch" },
                        options: ["switchLabel"],
                      },
                      {
                        element: "span",
                        also: ["sk-switch__control"],
                        attrs: { "aria-hidden": "true" },
                        children: [{ element: "span", also: ["sk-switch__thumb"] }],
                      },
                    ],
                  },
                  {
                    element: "span",
                    part: "densityEdge",
                    attrs: { "data-density": "full" },
                    slot: "fullLabel",
                  },
                ],
              },
            ],
          },
          {
            element: "div",
            part: "preview",
            children: [
              {
                element: "div",
                part: "viewport",
                attrs: { "data-sk-code-preview-density-panel": "condensed" },
                slot: "condensed",
                preserveWhitespace: true,
              },
              {
                element: "div",
                part: "viewport",
                attrs: { "data-sk-code-preview-density-panel": "full" },
                slot: "full",
                preserveWhitespace: true,
              },
            ],
          },
          {
            element: "div",
            part: "more",
            mount: codePreviewAttrs.more,
            whenGiven: "collapsible",
            children: [
              {
                element: "button",
                part: "toggle",
                also: ["sk-button", "sk-interactive"],
                mount: codePreviewAttrs.toggle,
                options: ["lessLabel"],
                attrs: {
                  type: "button",
                  "aria-expanded": "false",
                  "data-size": "sm",
                  "data-variant": "ghost",
                },
                children: [
                  { element: "span", mount: codePreviewAttrs.toggleLabel, textFromOption: "moreLabel" },
                  { element: "span", part: "toggleCount" },
                  {
                    element: "span",
                    part: "toggleIcon",
                    children: [
                      { element: "span", attrs: { "data-sk-icon": "chevron-down", "data-sk-icon-size": "sm" } },
                    ],
                  },
                ],
              },
            ],
          },
        ],
      },
      react: { from: "@skryensya/react/code-preview", name: "CodePreviewDensity" },
    },

  },
} as const satisfies ComponentContract;
