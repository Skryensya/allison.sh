<script lang="ts">
  import { datePicker } from "@skryensya/core/machines";
  import {
    calendarContract,
    calendarEvents,
    calendarParts,
    defaultDayLabel,
    defaultNextTriggerLabel,
    defaultPrevTriggerLabel,
    defaultViewTriggerLabel,
    parseCalendarDate,
    unusedIntlTranslations,
  } from "@skryensya/core/calendar";
  import { normalizeProps, useMachine } from "@zag-js/svelte";
  import { onMount } from "svelte";
  import { bindParts } from "../runtime/bind-part.svelte";
  import { getRoot, uniqueId } from "../runtime/svelte-hydrate";
  import { remountIcons } from "../icon.js";
  import CalendarView from "./CalendarView.svelte";

  /*
   * CALENDAR, standalone: the same `@zag-js/date-picker` machine as DatePicker, but `inline: true`
   * and none of the field parts (label/control/input/trigger/clear). Where DatePicker nests
   * `CalendarView` inside its popover positioner, this root IS the calendar: no field, no popup.
   */
  const root = getRoot();
  if (!root.id) root.id = uniqueId("sk-calendar");
  const locale = root.dataset.locale || calendarContract.options.locale.default;

  const service = useMachine(datePicker.machine, () => ({
    id: root.id,
    locale,
    timeZone: root.dataset.timeZone || "UTC",
    selectionMode: (root.dataset.selectionMode === "range" ? "range" : "single") as "single" | "range",
    /*
     * The preselected date. Absent until now, which meant authored markup had no way to say one at
     * all. A calendar could only ever open on today, and the React binding accepted a value the
     * enhancer silently dropped. Space-separated so a range can name both ends the way it reads.
     */
    defaultValue: root.dataset.value
      ?.split(" ")
      .filter(Boolean)
      .map((date) => parseCalendarDate(date)!)
      .filter(Boolean),
    min: parseCalendarDate(root.dataset.min),
    max: parseCalendarDate(root.dataset.max),
    disabled: root.hasAttribute("data-disabled"),
    readOnly: root.hasAttribute("data-readonly"),
    inline: true,
    fixedWeeks: true,
    /*
     * Zag's own `defaultTranslations` is English-only, unconditionally. A Spanish-locale calendar
     * announced "Choose 15 de agosto" in English otherwise, matching the same gap fixed in the React
     * binding. `trigger`/`content` name a popover this component never renders (`inline: true`).
     */
    translations: {
      ...unusedIntlTranslations(),
      trigger: () => "",
      content: "",
      dayCell: defaultDayLabel(locale),
      viewTrigger: defaultViewTriggerLabel(locale),
      prevTrigger: defaultPrevTriggerLabel(locale),
      nextTrigger: defaultNextTriggerLabel(locale),
    },
    onValueChange(details: { valueAsString: string[] }) {
      root.dispatchEvent(
        new CustomEvent(calendarEvents.valueChange, { bubbles: true, detail: { value: details.valueAsString } }),
      );
    },
  }));

  const api = $derived(datePicker.connect(service, normalizeProps));

  bindParts([{ part: "root", node: () => root, props: () => api.getRootProps() }]);

  onMount(() => {
    remountIcons(root);
  });
</script>

<CalendarView {api} {locale} />
